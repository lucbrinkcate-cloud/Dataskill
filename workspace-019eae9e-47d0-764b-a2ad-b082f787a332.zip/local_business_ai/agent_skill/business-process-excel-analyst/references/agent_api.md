# Business Process Excel Analyst CLI API

This reference is for agents/harnesses that prefer a deterministic command interface.

## Golden workflow

1. Run `inspect`.
2. Summarize detection and proposed plan to the user.
3. Ask the user to confirm or change approach.
4. Only after confirmation, run `batch` or `document`.
5. Return generated file paths.

For a user-friendly local UI, launch the pre-built dashboard from the engine directory:

```bash
cd "$BUSINESS_AI_HOME" && python app.py
# open http://127.0.0.1:5000
```

## Inspect

```bash
python scripts/business_excel_skill.py inspect --files FILE_OR_GLOB [FILE_OR_GLOB ...]
```

Returns JSON with sheet summaries, inferred column roles, product row counts and sample products.

## Batch generation

By default, every run creates a dated session folder inside `--out-dir`, for example:

```text
outputs/2026-06-10/2026-06-10_14-22-05_full_report_a1b2c3/
```

The JSON response includes `session_dir`. Use `--flat-output` only if you want to disable this.

```bash
python scripts/business_excel_skill.py batch \
  --files "data/*.xlsx" \
  --output full_report,margin_analysis,production_optimization,product_comparison,scenario_analysis \
  --formats html,pdf,docx \
  --audit \
  --out-dir outputs \
  --currency "€"
```

Natural language output inference:

```bash
python scripts/business_excel_skill.py batch --files "data/*.xlsx" --request "make margin reports and production location recommendations"
```

Output names:

- `invoice`
- `quotation`
- `full_report`
- `margin_analysis`
- `production_optimization`
- `product_comparison`
- `scenario_analysis`
- `schema_report`

Export formats:

- `html`
- `pdf`
- `docx`

## Single invoice/quotation

```bash
python scripts/business_excel_skill.py document \
  --file workbook.xlsx \
  --type invoice \
  --select sku:A-100,B-200 \
  --quantities 'A-100:10,B-200:5' \
  --company "Seller BV" \
  --customer "Buyer BV" \
  --tax-rate 21 \
  --template invoice_basic \
  --formats html,pdf,docx \
  --audit \
  --out outputs/invoice.html
```

## Template management

List templates:

```bash
python scripts/business_excel_skill.py templates list
```

Create editable copy:

```bash
python scripts/business_excel_skill.py templates create --name acme_invoice --from-template invoice_basic
```

Show template source:

```bash
python scripts/business_excel_skill.py templates show --name acme_invoice
```

Generate context JSON for template editing:

```bash
python scripts/business_excel_skill.py templates context --file workbook.xlsx --type invoice --select all --out context.json
```

Update/save template from edited file:

```bash
python scripts/business_excel_skill.py templates update --name acme_invoice --file edited_invoice.html.j2
```

Use saved template:

```bash
python scripts/business_excel_skill.py document --file workbook.xlsx --type invoice --template acme_invoice --select all
```

## Approval workflow

List draft/review status:

```bash
python scripts/business_excel_skill.py approvals list
```

Set status:

```bash
python scripts/business_excel_skill.py approvals set-status --path outputs/invoice.html --status approved --notes "Reviewed by finance"
```

Statuses:

- `draft`
- `reviewed`
- `approved`
- `sent`
- `rejected`
- `revised`

## Template variables

Templates are HTML/Jinja2. Main variables:

- `style`: default CSS
- `generated_date`
- `workbook.filename`, `workbook.path`
- `document.type`, `document.number`, `document.date`, `document.valid_until`
- `document.currency`, `document.tax_rate`, `document.subtotal`, `document.tax`, `document.total`, `document.notes`
- `company.name`
- `customer.name`
- `lines`: list of selected line items
  - `line.index`
  - `line.sku`
  - `line.description`
  - `line.category`
  - `line.location`
  - `line.quantity`
  - `line.unit_price`
  - `line.line_total`
  - `line.unit_cost`
  - `line.margin_unit`
  - `line.margin_pct`

Filters:

- `{{ value|currency(document.currency) }}`
- `{{ value|number(2) }}`
- `{{ value|pct }}`

## Exit codes

- `0`: success
- `1`: generation error or partial failure
- `2`: bad input/no files
- `130`: interrupted
