from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd

from .excel_reader import SheetTable, WorkbookData
from .html_renderer import badge, bar_chart, card, dataframe_table, esc, fmt_currency, fmt_number, fmt_pct, kpi, render_page
from .llm import OllamaClient
from .schema_mapper import COST_ROLES, first_existing, normalize_text, safe_number


@dataclass
class ProductItem:
    id: str
    source_sheet: str
    source_row: int
    sku: str = ""
    name: str = ""
    category: str = ""
    location: str = ""
    supplier: str = ""
    unit_price: float = math.nan
    unit_cost: float = math.nan
    material_cost: float = math.nan
    labor_cost: float = math.nan
    handling_cost: float = math.nan
    overhead_cost: float = math.nan
    quantity: float = math.nan
    capacity: float = math.nan
    margin_pct: float = math.nan
    raw: Dict[str, Any] = field(default_factory=dict)

    def total_cost(self) -> float:
        # Prefer explicit unit cost, otherwise sum components.
        if self.unit_cost == self.unit_cost and self.unit_cost > 0:
            return float(self.unit_cost)
        total = 0.0
        found = False
        for v in [self.material_cost, self.labor_cost, self.handling_cost, self.overhead_cost]:
            if v == v:
                total += float(v)
                found = True
        return total if found else float("nan")

    def margin_value(self) -> float:
        c = self.total_cost()
        if self.unit_price == self.unit_price and c == c:
            return self.unit_price - c
        return float("nan")

    def margin_rate(self) -> float:
        if self.margin_pct == self.margin_pct:
            return self.margin_pct / 100.0 if abs(self.margin_pct) > 1.5 else self.margin_pct
        mv = self.margin_value()
        if self.unit_price == self.unit_price and self.unit_price:
            return mv / self.unit_price
        return float("nan")

    def display_name(self) -> str:
        if self.name and self.sku:
            return f"{self.sku} — {self.name}"
        return self.name or self.sku or f"Row {self.source_row + 1}"


@dataclass
class SelectedLine:
    product: ProductItem
    quantity: float
    override_price: Optional[float] = None
    discount_pct: float = 0.0

    @property
    def unit_price(self) -> float:
        if self.override_price is not None and self.override_price == self.override_price:
            return self.override_price
        if self.product.unit_price == self.product.unit_price:
            return self.product.unit_price
        # Fallback: cost plus 30% markup if no sales price exists.
        c = self.product.total_cost()
        return c * 1.30 if c == c else 0.0

    @property
    def line_total(self) -> float:
        return self.quantity * self.unit_price * (1 - self.discount_pct / 100.0)


def _get_cell(row: pd.Series, col: Optional[str], default: Any = "") -> Any:
    if not col or col not in row:
        return default
    value = row[col]
    if pd.isna(value):
        return default
    return value


def _get_num(row: pd.Series, col: Optional[str], default: float = math.nan) -> float:
    if not col or col not in row:
        return default
    return safe_number(row[col], default)


def extract_products(workbook: WorkbookData, max_rows_per_table: int = 5000) -> List[ProductItem]:
    products: List[ProductItem] = []
    for table in workbook.tables:
        schema = table.schema
        if not schema:
            continue
        roles = schema.roles
        # A table can be product-like if it has a name/code plus either price/cost/quantity/location.
        has_identity = any(r in roles for r in ["product", "sku"])
        has_business_values = any(r in roles for r in ["unit_price", "unit_cost", "material_cost", "labor_cost", "handling_cost", "overhead_cost", "quantity", "location", "capacity", "margin"])
        # Competitor/market benchmark sheets often contain product names and market prices,
        # but they are not company products to invoice or manufacture. Keep them for the
        # market-comparison section instead of mixing them into internal product rows.
        looks_like_external_market = "competitor" in roles and not any(
            r in roles for r in ["unit_cost", "material_cost", "labor_cost", "handling_cost", "overhead_cost", "quantity", "capacity"]
        )
        if not (has_identity and has_business_values) or looks_like_external_market:
            continue
        product_col = schema.role_column("product")
        sku_col = schema.role_column("sku")
        category_col = schema.role_column("category")
        location_col = schema.role_column("location")
        supplier_col = schema.role_column("supplier")
        price_col = schema.role_column("unit_price")
        cost_col = schema.role_column("unit_cost")
        material_col = schema.role_column("material_cost")
        labor_col = schema.role_column("labor_cost")
        handling_col = schema.role_column("handling_cost")
        overhead_col = schema.role_column("overhead_cost")
        qty_col = schema.role_column("quantity")
        capacity_col = schema.role_column("capacity")
        margin_col = schema.role_column("margin")
        for idx, row in table.dataframe.head(max_rows_per_table).iterrows():
            name = str(_get_cell(row, product_col, "")).strip()
            sku = str(_get_cell(row, sku_col, "")).strip()
            if not name and not sku:
                continue
            item = ProductItem(
                id=f"{len(products)}",
                source_sheet=table.name,
                source_row=int(idx),
                sku=sku,
                name=name,
                category=str(_get_cell(row, category_col, "")).strip(),
                location=str(_get_cell(row, location_col, "")).strip(),
                supplier=str(_get_cell(row, supplier_col, "")).strip(),
                unit_price=_get_num(row, price_col),
                unit_cost=_get_num(row, cost_col),
                material_cost=_get_num(row, material_col),
                labor_cost=_get_num(row, labor_col),
                handling_cost=_get_num(row, handling_col),
                overhead_cost=_get_num(row, overhead_col),
                quantity=_get_num(row, qty_col),
                capacity=_get_num(row, capacity_col),
                margin_pct=_get_num(row, margin_col),
                raw=row.where(pd.notna(row), "").to_dict(),
            )
            # Filter obvious metadata rows.
            if normalize_text(item.name) in {"total", "subtotal", "grand total"}:
                continue
            products.append(item)
    return products


def products_to_dataframe(products: Sequence[ProductItem]) -> pd.DataFrame:
    rows = []
    for p in products:
        rows.append({
            "ID": p.id,
            "Sheet": p.source_sheet,
            "SKU": p.sku,
            "Product": p.name,
            "Category": p.category,
            "Location": p.location,
            "Supplier": p.supplier,
            "Unit price": p.unit_price,
            "Total unit cost": p.total_cost(),
            "Material": p.material_cost,
            "Labor": p.labor_cost,
            "Handling": p.handling_cost,
            "Overhead": p.overhead_cost,
            "Margin/unit": p.margin_value(),
            "Margin %": p.margin_rate(),
            "Quantity/demand": p.quantity,
            "Capacity": p.capacity,
        })
    return pd.DataFrame(rows)


def product_options_html(products: Sequence[ProductItem], currency: str = "€", max_rows: int = 300) -> str:
    if not products:
        return "<p class='warn'>No product-like rows were detected. Upload a workbook containing product/item names plus price or cost columns.</p>"
    rows = []
    for p in products[:max_rows]:
        price = fmt_currency(p.unit_price if p.unit_price == p.unit_price else p.total_cost() * 1.3, currency)
        cost = fmt_currency(p.total_cost(), currency)
        margin = fmt_pct(p.margin_rate())
        rows.append(f"""
        <tr>
          <td><input type="checkbox" name="selected" value="{esc(p.id)}"></td>
          <td><strong>{esc(p.display_name())}</strong><div class="small">Sheet: {esc(p.source_sheet)} · Location: {esc(p.location or '—')}</div></td>
          <td>{esc(p.category or '—')}</td>
          <td class="num">{price}</td>
          <td class="num">{cost}</td>
          <td class="num">{margin}</td>
          <td><input type="number" name="qty_{esc(p.id)}" min="0" step="0.01" placeholder="0" style="width:90px"></td>
          <td><input type="number" name="price_{esc(p.id)}" min="0" step="0.01" placeholder="optional" style="width:105px"></td>
        </tr>
        """)
    more = "" if len(products) <= max_rows else f"<p class='small'>Showing first {max_rows} detected products. Refine the workbook or use CLI for very large documents.</p>"
    return f"""
    <div class="table-wrap">
      <table>
        <thead><tr><th>Select</th><th>Item</th><th>Category</th><th>Detected price</th><th>Detected cost</th><th>Margin</th><th>Quantity</th><th>Override unit price</th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table>
    </div>{more}
    """


def _selected_lines_from_form(products: Sequence[ProductItem], form: Dict[str, Any]) -> List[SelectedLine]:
    selected = form.getlist("selected") if hasattr(form, "getlist") else form.get("selected", [])
    if isinstance(selected, str):
        selected = [selected]
    by_id = {p.id: p for p in products}
    lines: List[SelectedLine] = []
    for pid in selected:
        p = by_id.get(str(pid))
        if not p:
            continue
        qty = safe_number(form.get(f"qty_{pid}", 0), 0.0)
        if qty <= 0:
            qty = 1.0
        price_raw = form.get(f"price_{pid}", "")
        override_price = None
        if str(price_raw).strip():
            override_price = safe_number(price_raw, math.nan)
        lines.append(SelectedLine(product=p, quantity=qty, override_price=override_price))
    return lines


def render_invoice_or_quote(
    document_type: str,
    lines: Sequence[SelectedLine],
    company: str = "Your Company",
    customer: str = "Customer",
    currency: str = "€",
    tax_rate: float = 21.0,
    notes: str = "",
    output_path: Optional[str] = None,
    llm_summary: str = "",
) -> str:
    document_type = "Quotation" if document_type.lower().startswith("quote") else "Invoice"
    doc_no_prefix = "QUO" if document_type == "Quotation" else "INV"
    doc_no = f"{doc_no_prefix}-{date.today().strftime('%Y%m%d')}-{str(uuid.uuid4())[:6].upper()}"
    subtotal = sum(line.line_total for line in lines)
    tax = subtotal * (tax_rate / 100.0)
    total = subtotal + tax
    valid_until = date.today() + timedelta(days=30)

    line_rows = []
    for line in lines:
        p = line.product
        cost = p.total_cost()
        margin = line.unit_price - cost if cost == cost else math.nan
        line_rows.append({
            "SKU": p.sku,
            "Description": p.name or p.display_name(),
            "Location": p.location,
            "Qty": line.quantity,
            "Unit price": line.unit_price,
            "Discount %": line.discount_pct,
            "Line total": line.line_total,
            "Est. margin/unit": margin,
            "Margin %": (margin / line.unit_price) if line.unit_price else math.nan,
        })
    df = pd.DataFrame(line_rows)
    body = f"""
    <div class="doc-header">
      <div>
        <div class="doc-title">{esc(document_type)}</div>
        <p><strong>{esc(company)}</strong><br>{esc(customer)}</p>
        <p class="small">Document no: {esc(doc_no)}<br>Date: {date.today().isoformat()}<br>{'Valid until: ' + valid_until.isoformat() if document_type == 'Quotation' else 'Payment due: ' + valid_until.isoformat()}</p>
      </div>
      <div class="total-box"><div>Total incl. tax</div><div class="big">{fmt_currency(total, currency)}</div><div class="small" style="color:rgba(255,255,255,.78)">Subtotal {fmt_currency(subtotal, currency)} · Tax {fmt_currency(tax, currency)}</div></div>
    </div>
    <hr>
    {dataframe_table(df, currency=currency, numeric_currency_cols=['Unit price','Line total','Est. margin/unit'], pct_cols=['Discount %','Margin %'])}
    <div style="max-width:440px;margin-left:auto;margin-top:18px" class="table-wrap">
      <table>
        <tr><th>Subtotal</th><td class="num">{fmt_currency(subtotal, currency)}</td></tr>
        <tr><th>Tax/VAT {fmt_pct(tax_rate/100)}</th><td class="num">{fmt_currency(tax, currency)}</td></tr>
        <tr><th>Total</th><td class="num"><strong>{fmt_currency(total, currency)}</strong></td></tr>
      </table>
    </div>
    {f'<div class="note"><strong>Notes:</strong><br>{esc(notes)}</div>' if notes else ''}
    {f'<h3>AI-assisted commercial note</h3><div class="ai-box">{esc(llm_summary)}</div>' if llm_summary else ''}
    """
    return render_page(document_type, f"{doc_no} · {company}", [card(document_type, body)], output_path)


def _valid_margin_products(products: Sequence[ProductItem]) -> List[ProductItem]:
    return [p for p in products if p.unit_price == p.unit_price and p.unit_price > 0 and p.total_cost() == p.total_cost()]


def margin_analysis(workbook: WorkbookData, currency: str = "€", llm: Optional[OllamaClient] = None, output_path: Optional[str] = None) -> str:
    products = extract_products(workbook)
    valid = _valid_margin_products(products)
    df = products_to_dataframe(valid)
    if not valid:
        sections = [card("Margin analysis", "<p class='warn'>No rows with both unit price and unit cost/component costs were detected. Add price and cost columns to the workbook or adjust column names.</p>")]
        return render_page("Margin Analysis", workbook.filename, sections, output_path)

    df["Estimated total profit"] = df["Margin/unit"] * df["Quantity/demand"].fillna(1)
    avg_margin = df["Margin %"].dropna().mean()
    best = df.sort_values("Margin %", ascending=False).head(10)
    worst = df.sort_values("Margin %", ascending=True).head(10)
    total_profit = df["Estimated total profit"].dropna().sum()
    revenue = (df["Unit price"] * df["Quantity/demand"].fillna(1)).dropna().sum()
    cogs = (df["Total unit cost"] * df["Quantity/demand"].fillna(1)).dropna().sum()

    kpis = "<div class='grid'>" + "".join([
        kpi("Detected products", fmt_number(len(valid), 0), "Rows with price and cost"),
        kpi("Average margin", fmt_pct(avg_margin), "Unweighted average margin"),
        kpi("Estimated profit", fmt_currency(total_profit, currency), "Uses quantity/demand when detected"),
        kpi("Revenue / COGS", f"{fmt_currency(revenue, currency)} / {fmt_currency(cogs, currency)}", "Workbook-derived"),
    ]) + "</div>"

    suggestion_rows = []
    for _, row in worst.head(8).iterrows():
        reasons = []
        if row.get("Handling", math.nan) == row.get("Handling", math.nan) and row["Total unit cost"]:
            handling_share = row["Handling"] / row["Total unit cost"]
            if handling_share > 0.18:
                reasons.append("handling/logistics is a high cost share")
        if row["Margin %"] < avg_margin:
            gap = avg_margin - row["Margin %"]
            reasons.append(f"margin is {fmt_pct(gap)} below average")
        if row["Unit price"] and row["Margin %"] < 0.15:
            target_price = row["Total unit cost"] / max(0.01, 1 - max(avg_margin, 0.20))
            reasons.append(f"target price near {fmt_currency(target_price, currency)} to reach healthier margin")
        suggestion_rows.append({
            "Product": row["Product"] or row["SKU"],
            "Current margin": row["Margin %"],
            "Main improvement angle": "; ".join(reasons) or "review price, BOM, supplier terms, and production location",
        })
    suggestions = pd.DataFrame(suggestion_rows)

    ai_text = ""
    if llm:
        prompt = f"""
You are a manufacturing and commercial finance analyst. Explain the margin performance from this workbook in practical business language.
Focus on strongest margins, weakest margins, likely reasons, and concrete improvement actions. Do not invent exact market prices.

Workbook file: {workbook.filename}
Average margin: {avg_margin}
Top products: {best[['SKU','Product','Category','Location','Unit price','Total unit cost','Margin %','Quantity/demand']].to_dict(orient='records')}
Weak products: {worst[['SKU','Product','Category','Location','Unit price','Total unit cost','Margin %','Quantity/demand']].to_dict(orient='records')}
"""
        result = llm.generate(prompt, system="Return concise executive insight with bullet points. Use only the provided workbook data for numeric claims.")
        ai_text = result.text if result.ok else f"Local AI insight unavailable: {result.error}"

    chart_data = [(str(r["Product"] or r["SKU"]), float(r["Margin %"])) for _, r in best.iterrows()]
    worst_chart = [(str(r["Product"] or r["SKU"]), float(r["Margin %"])) for _, r in worst.iterrows()]
    sections = [
        card("Executive KPIs", kpis),
        card("Strongest margin products", bar_chart(chart_data, "Top margin %", currency, value_type="pct") + dataframe_table(best, currency, numeric_currency_cols=["Unit price", "Total unit cost", "Margin/unit", "Estimated total profit"], pct_cols=["Margin %"])),
        card("Underperforming margins and improvement options", bar_chart(worst_chart, "Lowest margin %", currency, value_type="pct") + dataframe_table(suggestions, currency, pct_cols=["Current margin"])),
    ]
    if ai_text:
        sections.append(card("Local AI commentary", f"<div class='ai-box'>{esc(ai_text)}</div>"))
    return render_page("Margin Analysis", f"Workbook: {workbook.filename}", sections, output_path)


def production_optimization(workbook: WorkbookData, currency: str = "€", llm: Optional[OllamaClient] = None, output_path: Optional[str] = None) -> str:
    products = extract_products(workbook)
    df = products_to_dataframe(products)
    if df.empty or "Location" not in df.columns or not df["Location"].astype(str).str.strip().any():
        sections = [card("Production optimization", "<p class='warn'>No production/location column was detected. To optimize location split, include columns such as country/plant/site plus unit cost or cost components, demand, and optional capacity.</p>")]
        return render_page("Production Optimization", workbook.filename, sections, output_path)

    df = df[df["Location"].astype(str).str.strip() != ""].copy()
    df["Demand"] = df["Quantity/demand"].apply(lambda x: x if x == x and x > 0 else 1.0)
    # Aggregate by product+location, choosing lowest detected cost for duplicate rows.
    usable = df[df["Total unit cost"].notna()].copy()
    if usable.empty:
        sections = [card("Production optimization", "<p class='warn'>Locations were detected, but no unit cost or cost-component columns were found.</p>")]
        return render_page("Production Optimization", workbook.filename, sections, output_path)

    grouped_rows = []
    for (product, sku), prod_df in usable.groupby(["Product", "SKU"], dropna=False):
        demand = prod_df["Demand"].max() if prod_df["Demand"].notna().any() else 1.0
        # If product name missing, use SKU.
        product_label = product or sku or "Unnamed product"
        locs = prod_df.sort_values("Total unit cost")
        remaining = demand
        for _, loc_row in locs.iterrows():
            capacity = loc_row.get("Capacity", math.nan)
            if capacity == capacity and capacity > 0:
                qty = min(remaining, capacity)
            else:
                qty = remaining
            if qty <= 0:
                continue
            grouped_rows.append({
                "Product": product_label,
                "SKU": sku,
                "Recommended location": loc_row["Location"],
                "Allocated volume": qty,
                "Unit cost": loc_row["Total unit cost"],
                "Estimated production cost": qty * loc_row["Total unit cost"],
                "Reason": "lowest landed/unit cost" if len(locs) > 1 else "only detected location",
            })
            remaining -= qty
            if remaining <= 0:
                break
        if remaining > 0 and len(locs) > 0:
            # Capacity shortage; allocate residual to lowest cost as warning.
            loc_row = locs.iloc[0]
            grouped_rows.append({
                "Product": product_label,
                "SKU": sku,
                "Recommended location": loc_row["Location"],
                "Allocated volume": remaining,
                "Unit cost": loc_row["Total unit cost"],
                "Estimated production cost": remaining * loc_row["Total unit cost"],
                "Reason": "capacity shortage fallback; validate capacity data",
            })

    rec = pd.DataFrame(grouped_rows)
    location_summary = rec.groupby("Recommended location", as_index=False).agg({
        "Allocated volume": "sum",
        "Estimated production cost": "sum",
    }).sort_values("Estimated production cost", ascending=False)
    location_costs = usable.groupby("Location", as_index=False).agg({
        "Total unit cost": ["mean", "min", "max"],
        "Material": "mean",
        "Labor": "mean",
        "Handling": "mean",
        "Overhead": "mean",
    })
    location_costs.columns = [" ".join(c).strip() for c in location_costs.columns.to_flat_index()]
    # Raw material fluctuation proxy: range of material cost by location.
    raw_fluct = usable.groupby("Location", as_index=False).agg({"Material": ["mean", "min", "max"]})
    raw_fluct.columns = [" ".join(c).strip() for c in raw_fluct.columns.to_flat_index()]
    if "Material max" in raw_fluct and "Material min" in raw_fluct:
        raw_fluct["Material fluctuation"] = raw_fluct["Material max"] - raw_fluct["Material min"]

    ai_text = ""
    if llm:
        prompt = f"""
You are a production strategy analyst. Interpret the production location optimization below.
Explain where production should be structured, how volume should be divided, and what data risks/assumptions should be checked.
Use the workbook data only for numeric claims.

Recommended allocation: {rec.head(50).to_dict(orient='records')}
Location cost summary: {location_costs.head(50).to_dict(orient='records')}
Raw material fluctuation proxy: {raw_fluct.head(50).to_dict(orient='records')}
"""
        result = llm.generate(prompt, system="Return concise, practical recommendations with bullet points and caveats.")
        ai_text = result.text if result.ok else f"Local AI insight unavailable: {result.error}"

    total_cost = rec["Estimated production cost"].sum() if not rec.empty else 0
    total_volume = rec["Allocated volume"].sum() if not rec.empty else 0
    cheapest_location = usable.groupby("Location")["Total unit cost"].mean().sort_values().index[0]
    sections = [
        card("Production structure KPIs", "<div class='grid'>" + "".join([
            kpi("Recommended total volume", fmt_number(total_volume, 0), "Based on detected demand/quantity"),
            kpi("Estimated production cost", fmt_currency(total_cost, currency), "Recommended allocation"),
            kpi("Lowest average cost location", str(cheapest_location), "Mean detected unit cost"),
            kpi("Detected locations", fmt_number(usable["Location"].nunique(), 0), "Plants/countries/sites"),
        ]) + "</div>"),
        card("Recommended volume split", bar_chart([(str(r["Recommended location"]), float(r["Allocated volume"])) for _, r in location_summary.iterrows()], "Volume by location", currency, value_type="number") + dataframe_table(rec, currency, numeric_currency_cols=["Unit cost", "Estimated production cost"])),
        card("Production costs by location", dataframe_table(location_costs, currency, numeric_currency_cols=[c for c in location_costs.columns if c != "Location"])),
        card("Raw material price fluctuation proxy", dataframe_table(raw_fluct, currency, numeric_currency_cols=[c for c in raw_fluct.columns if c != "Location"])),
    ]
    if ai_text:
        sections.append(card("Local AI production recommendation", f"<div class='ai-box'>{esc(ai_text)}</div>"))
    return render_page("Production Optimization", f"Workbook: {workbook.filename}", sections, output_path)


def product_comparison(workbook: WorkbookData, currency: str = "€", llm: Optional[OllamaClient] = None, output_path: Optional[str] = None) -> str:
    products = extract_products(workbook)
    df = products_to_dataframe(products)
    if df.empty:
        sections = [card("Product comparison", "<p class='warn'>No product-like table was detected. Include product/item descriptions and price/cost/component columns.</p>")]
        return render_page("Product Comparison", workbook.filename, sections, output_path)

    # Group similar internal products by category when available, otherwise product token prefix.
    df["Compare group"] = df["Category"].where(df["Category"].astype(str).str.strip() != "", df["Product"].astype(str).str.lower().str.extract(r"([a-zA-Z]+)", expand=False).fillna("Ungrouped"))
    group_summary = df.groupby("Compare group", as_index=False).agg({
        "Product": "count",
        "Unit price": "mean",
        "Total unit cost": "mean",
        "Margin %": "mean",
        "Handling": "mean",
        "Material": "mean",
        "Labor": "mean",
    }).rename(columns={"Product": "Products in group"}).sort_values("Margin %", ascending=False)

    # Market/external benchmark detection.
    market_tables = []
    for table in workbook.tables:
        name = normalize_text(table.name)
        roles = table.schema.roles if table.schema else {}
        if "competitor" in roles or "market" in name or "competitor" in name or "benchmark" in name:
            market_tables.append(table)
    market_note = ""
    market_html = ""
    if market_tables:
        samples = []
        for t in market_tables[:3]:
            samples.append(t.dataframe.head(20))
        market_df = pd.concat(samples, ignore_index=True, sort=False) if samples else pd.DataFrame()
        market_html = dataframe_table(market_df, currency=currency, max_rows=50)
        market_note = badge("Market/competitor sheet detected", "green")
    else:
        market_note = badge("No explicit market price sheet detected", "amber") + " <span class='small'>For current market comparison, add competitor/market benchmark data to the workbook. A local model has no live internet prices by itself.</span>"

    ai_text = ""
    if llm:
        prompt = f"""
You are a product and component comparison analyst. Compare the company's products/components using the data below.
Focus on cost drivers, handling costs, sales margins, similar internal products, and what would be needed for market benchmarking.
If competitor/market data is missing, clearly say that live market claims are not verified.

Product group summary: {group_summary.head(50).to_dict(orient='records')}
Product sample: {df.head(60).to_dict(orient='records')}
Market tables detected: {bool(market_tables)}
"""
        result = llm.generate(prompt, system="Return concise practical insights. Do not invent exact competitor prices unless provided in data.")
        ai_text = result.text if result.ok else f"Local AI insight unavailable: {result.error}"

    sections = [
        card("Comparison KPIs", "<div class='grid'>" + "".join([
            kpi("Detected products/components", fmt_number(len(df), 0), "Across all readable sheets"),
            kpi("Comparison groups", fmt_number(group_summary["Compare group"].nunique(), 0), "Category or name-based"),
            kpi("Average unit cost", fmt_currency(df["Total unit cost"].dropna().mean(), currency), "Detected cost/component columns"),
            kpi("Average margin", fmt_pct(df["Margin %"].dropna().mean()), "Where price and cost exist"),
        ]) + "</div>"),
        card("Internal product/component groups", dataframe_table(group_summary, currency, numeric_currency_cols=["Unit price", "Total unit cost", "Handling", "Material", "Labor"], pct_cols=["Margin %"])),
        card("Product-level comparison", dataframe_table(df.sort_values("Margin %", ascending=False), currency, max_rows=120, numeric_currency_cols=["Unit price", "Total unit cost", "Material", "Labor", "Handling", "Overhead", "Margin/unit"], pct_cols=["Margin %"])),
        card("Market / competitor comparison", f"<p>{market_note}</p>{market_html}"),
    ]
    if ai_text:
        sections.append(card("Local AI comparison insight", f"<div class='ai-box'>{esc(ai_text)}</div>"))
    return render_page("Product & Component Comparison", f"Workbook: {workbook.filename}", sections, output_path)


def schema_report(workbook: WorkbookData, currency: str = "€", llm: Optional[OllamaClient] = None, output_path: Optional[str] = None) -> str:
    rows = []
    for t in workbook.tables:
        rows.append({
            "Sheet": t.name,
            "Rows": t.rows,
            "Columns": len(t.columns),
            "Detected roles": ", ".join(f"{role}: {match.column}" for role, match in (t.schema.roles.items() if t.schema else [])),
            "Score": t.schema.score if t.schema else 0,
            "Warnings": "; ".join(t.schema.warnings if t.schema else []),
        })
    df = pd.DataFrame(rows)
    ai_text = ""
    if llm:
        prompt = f"""
Review this arbitrary Excel workbook profile. Explain what business use cases appear possible and what columns/sheets are missing for invoices, quotations, margin analysis, production optimization and market comparison.

Workbook profile:
{workbook.compact_profile(max_rows_per_sheet=3)}
"""
        result = llm.generate(prompt, system="Return a concise schema-readiness assessment. Do not invent data.")
        ai_text = result.text if result.ok else f"Local AI schema assessment unavailable: {result.error}"
    sections = [card("Workbook/schema detection", dataframe_table(df, currency, pct_cols=[]))]
    if workbook.errors:
        sections.append(card("Read warnings", "<div class='warn'>" + esc("\n".join(workbook.errors)) + "</div>"))
    if ai_text:
        sections.append(card("Local AI schema assessment", f"<div class='ai-box'>{esc(ai_text)}</div>"))
    return render_page("Workbook Schema Report", f"Workbook: {workbook.filename}", sections, output_path)


def full_report(workbook: WorkbookData, currency: str = "€", llm: Optional[OllamaClient] = None, output_path: Optional[str] = None) -> str:
    """Combined report for management: schema, margins, production and comparison in one HTML file."""
    products = extract_products(workbook)
    df = products_to_dataframe(products)
    sections: List[str] = []

    if df.empty:
        sections.append(card(
            "No product data detected",
            "<p class='warn'>The workbook was read, but the tool could not confidently detect product/item rows with price, cost, quantity, or location data. Open the schema report to see detected sheets and column roles.</p>",
        ))
    else:
        valid_margin = df[df["Unit price"].notna() & df["Total unit cost"].notna()].copy()
        avg_margin = valid_margin["Margin %"].mean() if not valid_margin.empty else math.nan
        total_revenue = (valid_margin["Unit price"] * valid_margin["Quantity/demand"].fillna(1)).sum() if not valid_margin.empty else math.nan
        total_profit = (valid_margin["Margin/unit"] * valid_margin["Quantity/demand"].fillna(1)).sum() if not valid_margin.empty else math.nan
        best = valid_margin.sort_values("Margin %", ascending=False).head(8) if not valid_margin.empty else pd.DataFrame()
        worst = valid_margin.sort_values("Margin %", ascending=True).head(8) if not valid_margin.empty else pd.DataFrame()

        sections.append(card("Executive overview", "<div class='grid'>" + "".join([
            kpi("Products/components detected", fmt_number(len(df), 0), "Across readable sheets"),
            kpi("Average gross margin", fmt_pct(avg_margin), "Where price and cost exist"),
            kpi("Estimated revenue", fmt_currency(total_revenue, currency), "Uses quantity/demand if available"),
            kpi("Estimated profit", fmt_currency(total_profit, currency), "Workbook-derived estimate"),
        ]) + "</div>"))

        if not best.empty:
            sections.append(card("Strongest margins", bar_chart([(str(r["Product"] or r["SKU"]), float(r["Margin %"])) for _, r in best.iterrows()], "Top margins", currency, value_type="pct") + dataframe_table(best, currency, numeric_currency_cols=["Unit price", "Total unit cost", "Margin/unit"], pct_cols=["Margin %"])))
        if not worst.empty:
            sections.append(card("Margins needing attention", bar_chart([(str(r["Product"] or r["SKU"]), float(r["Margin %"])) for _, r in worst.iterrows()], "Lowest margins", currency, value_type="pct") + dataframe_table(worst, currency, numeric_currency_cols=["Unit price", "Total unit cost", "Margin/unit"], pct_cols=["Margin %"])))

        # Lightweight production section.
        loc_df = df[df["Location"].astype(str).str.strip() != ""].copy() if "Location" in df else pd.DataFrame()
        if not loc_df.empty and loc_df["Total unit cost"].notna().any():
            loc_summary = loc_df.groupby("Location", as_index=False).agg({
                "Total unit cost": ["mean", "min", "max"],
                "Material": "mean",
                "Labor": "mean",
                "Handling": "mean",
                "Overhead": "mean",
                "Quantity/demand": "sum",
            })
            loc_summary.columns = [" ".join(c).strip() for c in loc_summary.columns.to_flat_index()]
            loc_summary = loc_summary.sort_values("Total unit cost mean")
            sections.append(card("Production location cost comparison", bar_chart([(str(r["Location"]), float(r["Total unit cost mean"])) for _, r in loc_summary.head(10).iterrows()], "Average unit cost by location", currency, value_type="currency") + dataframe_table(loc_summary, currency, numeric_currency_cols=[c for c in loc_summary.columns if c != "Location"])))
        else:
            sections.append(card("Production location comparison", "<p class='warn'>No usable location + cost combination detected. Add plant/country/site and cost columns for production optimization.</p>"))

        # Internal grouping section.
        df["Compare group"] = df["Category"].where(df["Category"].astype(str).str.strip() != "", df["Product"].astype(str).str.lower().str.extract(r"([a-zA-Z]+)", expand=False).fillna("Ungrouped"))
        group_summary = df.groupby("Compare group", as_index=False).agg({
            "Product": "count",
            "Unit price": "mean",
            "Total unit cost": "mean",
            "Margin %": "mean",
            "Handling": "mean",
        }).rename(columns={"Product": "Products in group"}).sort_values("Margin %", ascending=False)
        sections.append(card("Product/component group comparison", dataframe_table(group_summary, currency, numeric_currency_cols=["Unit price", "Total unit cost", "Handling"], pct_cols=["Margin %"])))

    # Schema section always included.
    schema_rows = []
    for t in workbook.tables:
        schema_rows.append({
            "Sheet": t.name,
            "Rows": t.rows,
            "Columns": len(t.columns),
            "Detected roles": ", ".join(f"{role}: {match.column}" for role, match in (t.schema.roles.items() if t.schema else [])),
            "Score": t.schema.score if t.schema else 0,
        })
    sections.append(card("Workbook/schema detection", dataframe_table(pd.DataFrame(schema_rows), currency)))

    ai_text = ""
    if llm:
        compact = df.head(80).to_dict(orient="records") if not df.empty else []
        prompt = f"""
You are an AI business process, manufacturing, and margin analyst. Create an executive HTML-report narrative in plain text/bullets from this workbook-derived data.
Cover:
1. How production should be structured and what location/cost evidence supports it.
2. Which products have strongest/weakest margins and likely reasons.
3. How underperforming margins can be improved.
4. What additional data is required for stronger market comparison.
Do not invent exact live market prices. Use only data provided for numeric claims.

Workbook: {workbook.filename}
Detected schema: {workbook.schema_summary()}
Product sample: {compact}
"""
        result = llm.generate(prompt, system="Return concise executive recommendations with bullets and clear caveats. Do not output HTML tags.")
        ai_text = result.text if result.ok else f"Local AI executive summary unavailable: {result.error}"
    if ai_text:
        sections.insert(1, card("Local AI executive recommendations", f"<div class='ai-box'>{esc(ai_text)}</div>"))

    return render_page("Business Process AI Report", f"Workbook: {workbook.filename}", sections, output_path)


def generate_selected_document_from_form(
    workbook: WorkbookData,
    form: Dict[str, Any],
    document_type: str,
    currency: str = "€",
    llm: Optional[OllamaClient] = None,
    output_path: Optional[str] = None,
) -> str:
    products = extract_products(workbook)
    lines = _selected_lines_from_form(products, form)
    if not lines:
        # Select the first product as a friendly fallback, so users still see an output.
        if products:
            lines = [SelectedLine(products[0], 1.0)]
        else:
            lines = []
    company = str(form.get("company", "Your Company") or "Your Company")
    customer = str(form.get("customer", "Customer") or "Customer")
    notes = str(form.get("notes", "") or "")
    tax_rate = safe_number(form.get("tax_rate", 21), 21.0)

    ai_note = ""
    if llm and lines:
        prompt = f"""
Draft a short commercial note for this {document_type}. Mention value proposition, delivery/pricing assumptions, and any margin considerations that should be checked internally. Keep it professional and concise.
Lines: {[{'sku': l.product.sku, 'product': l.product.name, 'qty': l.quantity, 'unit_price': l.unit_price, 'cost': l.product.total_cost(), 'location': l.product.location} for l in lines]}
"""
        result = llm.generate(prompt, system="Do not make legal promises. Use concise business language.")
        ai_note = result.text if result.ok else ""

    return render_invoice_or_quote(
        document_type=document_type,
        lines=lines,
        company=company,
        customer=customer,
        currency=currency,
        tax_rate=tax_rate,
        notes=notes,
        output_path=output_path,
        llm_summary=ai_note,
    )


def scenario_analysis(workbook: WorkbookData, currency: str = "€", llm: Optional[OllamaClient] = None, output_path: Optional[str] = None) -> str:
    """Create a sensitivity/scenario report for cost, price and margin shocks."""
    products = extract_products(workbook)
    valid = _valid_margin_products(products)
    if not valid:
        sections = [card("Scenario analysis", "<p class='warn'>No rows with both sales price and cost/component data were detected. Add price and cost columns to run sensitivity analysis.</p>")]
        return render_page("Scenario & Sensitivity Analysis", workbook.filename, sections, output_path)

    rows = []
    for p in valid:
        base_cost = p.total_cost()
        material = p.material_cost if p.material_cost == p.material_cost else 0.0
        handling = p.handling_cost if p.handling_cost == p.handling_cost else 0.0
        non_material_cost = base_cost - material
        non_handling_cost = base_cost - handling
        price = p.unit_price
        qty = p.quantity if p.quantity == p.quantity and p.quantity > 0 else 1.0
        scenarios = {
            "Base margin %": (price - base_cost) / price if price else math.nan,
            "Material +10% margin %": (price - (non_material_cost + material * 1.10)) / price if price else math.nan,
            "Material +25% margin %": (price - (non_material_cost + material * 1.25)) / price if price else math.nan,
            "Handling +15% margin %": (price - (non_handling_cost + handling * 1.15)) / price if price else math.nan,
            "Sales price -5% margin %": ((price * 0.95) - base_cost) / (price * 0.95) if price else math.nan,
        }
        target_margin = 0.30
        required_price_30 = base_cost / (1 - target_margin) if base_cost == base_cost else math.nan
        rows.append({
            "SKU": p.sku,
            "Product": p.name,
            "Location": p.location,
            "Quantity/demand": qty,
            "Unit price": price,
            "Base cost": base_cost,
            "Material cost": material if material else math.nan,
            "Handling cost": handling if handling else math.nan,
            **scenarios,
            "Price for 30% margin": required_price_30,
            "Current profit": (price - base_cost) * qty,
            "Profit if material +10%": (price - (non_material_cost + material * 1.10)) * qty,
            "Profit if price -5%": ((price * 0.95) - base_cost) * qty,
        })
    df = pd.DataFrame(rows)
    risk = df.copy()
    risk["Worst scenario margin %"] = risk[["Material +25% margin %", "Handling +15% margin %", "Sales price -5% margin %"]].min(axis=1)
    risk["Margin shock"] = risk["Base margin %"] - risk["Worst scenario margin %"]
    risk = risk.sort_values("Worst scenario margin %").head(12)

    ai_text = ""
    if llm:
        prompt = f"""
You are a commercial finance analyst. Interpret this sensitivity analysis.
Focus on products most exposed to raw material price increases, handling cost increases, and price pressure.
Use only these workbook-derived values for numeric claims.

Risk rows: {risk.head(30).to_dict(orient='records')}
"""
        result = llm.generate(prompt, system="Return concise recommendations and caveats. Do not invent market data.")
        ai_text = result.text if result.ok else f"Local AI scenario commentary unavailable: {result.error}"

    sections = [
        card("Scenario KPIs", "<div class='grid'>" + "".join([
            kpi("Products analysed", fmt_number(len(df), 0), "Rows with price and cost"),
            kpi("Average base margin", fmt_pct(df["Base margin %"].mean()), "Current workbook-derived margin"),
            kpi("Avg margin if material +10%", fmt_pct(df["Material +10% margin %"].mean()), "Sensitivity proxy"),
            kpi("Avg margin if price -5%", fmt_pct(df["Sales price -5% margin %"].mean()), "Price-pressure scenario"),
        ]) + "</div>"),
        card("Highest sensitivity / risk", dataframe_table(risk, currency, numeric_currency_cols=["Unit price", "Base cost", "Material cost", "Handling cost", "Price for 30% margin", "Current profit", "Profit if material +10%", "Profit if price -5%"], pct_cols=["Base margin %", "Material +10% margin %", "Material +25% margin %", "Handling +15% margin %", "Sales price -5% margin %", "Worst scenario margin %", "Margin shock"])),
        card("All product scenarios", dataframe_table(df.sort_values("Base margin %"), currency, max_rows=150, numeric_currency_cols=["Unit price", "Base cost", "Material cost", "Handling cost", "Price for 30% margin", "Current profit", "Profit if material +10%", "Profit if price -5%"], pct_cols=["Base margin %", "Material +10% margin %", "Material +25% margin %", "Handling +15% margin %", "Sales price -5% margin %"])),
    ]
    if ai_text:
        sections.append(card("Local AI sensitivity recommendations", f"<div class='ai-box'>{esc(ai_text)}</div>"))
    return render_page("Scenario & Sensitivity Analysis", f"Workbook: {workbook.filename}", sections, output_path)


def question_analysis(
    workbook: WorkbookData,
    question: str,
    currency: str = "€",
    llm: Optional[OllamaClient] = None,
    output_path: Optional[str] = None,
    offline_mode: bool = True,
) -> str:
    """Answer an ad-hoc business question from workbook data only.

    This is designed for questions like:
    - why is product A margin higher than product B?
    - why is production cheaper in Poland than China?
    - compare product A to market benchmarks in the uploaded files.
    """
    question = (question or "").strip() or "Explain the main business drivers in this workbook."
    products = extract_products(workbook)
    df = products_to_dataframe(products)
    if df.empty:
        return render_page(
            "Ad-hoc Business Question",
            f"Workbook: {workbook.filename}",
            [card("Question", f"<p>{esc(question)}</p><p class='warn'>No product-like data was detected. Generate a schema report or provide a mapping profile.</p>")],
            output_path,
        )

    q_tokens = {t for t in normalize_text(question).split() if len(t) >= 3}

    def relevance(row: pd.Series) -> int:
        text = normalize_text(" ".join(str(row.get(c, "")) for c in ["SKU", "Product", "Category", "Location", "Supplier"]))
        return sum(1 for t in q_tokens if t in text)

    df = df.copy()
    df["Relevance"] = df.apply(relevance, axis=1)
    relevant = df[df["Relevance"] > 0].copy()
    if relevant.empty:
        relevant = df.copy()
    relevant = relevant.sort_values(["Relevance", "Margin %"], ascending=[False, False]).head(30)

    # Product/SKU margin summary.
    margin_summary = relevant[[
        "SKU", "Product", "Category", "Location", "Unit price", "Total unit cost", "Material", "Labor", "Handling", "Overhead", "Margin/unit", "Margin %", "Quantity/demand"
    ]].copy()

    # Location comparison: useful for Poland vs China/other factory questions.
    loc_df = df[df["Location"].astype(str).str.strip() != ""].copy()
    loc_summary = pd.DataFrame()
    if not loc_df.empty:
        loc_summary = loc_df.groupby("Location", as_index=False).agg({
            "Total unit cost": ["mean", "min", "max", "count"],
            "Material": "mean",
            "Labor": "mean",
            "Handling": "mean",
            "Overhead": "mean",
            "Margin %": "mean",
        })
        loc_summary.columns = [" ".join(c).strip() for c in loc_summary.columns.to_flat_index()]
        loc_summary = loc_summary.sort_values("Total unit cost mean")

    # Find market/competitor sheets. Offline mode means uploaded files only.
    market_tables = []
    for table in workbook.tables:
        name = normalize_text(table.name)
        roles = table.schema.roles if table.schema else {}
        if "competitor" in roles or "market" in name or "competitor" in name or "benchmark" in name:
            market_tables.append(table)
    market_html = ""
    market_msg = ""
    if market_tables:
        samples = [t.dataframe.head(40) for t in market_tables[:4]]
        market_df = pd.concat(samples, ignore_index=True, sort=False) if samples else pd.DataFrame()
        market_html = dataframe_table(market_df, currency=currency, max_rows=80)
        market_msg = "Uploaded market/competitor benchmark data was detected and included below."
    else:
        market_msg = "No uploaded market/competitor benchmark sheet was detected. In offline mode, the tool will not fetch market data externally."

    # Deterministic explanation bullets.
    bullets: List[str] = []
    valid_margins = margin_summary[margin_summary["Unit price"].notna() & margin_summary["Total unit cost"].notna()].copy()
    if len(valid_margins) >= 2:
        top = valid_margins.sort_values("Margin %", ascending=False).iloc[0]
        low = valid_margins.sort_values("Margin %", ascending=True).iloc[0]
        price_gap = top["Unit price"] - low["Unit price"] if top["Unit price"] == top["Unit price"] and low["Unit price"] == low["Unit price"] else math.nan
        cost_gap = top["Total unit cost"] - low["Total unit cost"] if top["Total unit cost"] == top["Total unit cost"] and low["Total unit cost"] == low["Total unit cost"] else math.nan
        bullets.append(f"Highest relevant margin: {top.get('SKU','')} {top.get('Product','')} at {fmt_pct(top.get('Margin %'))}; lowest relevant margin: {low.get('SKU','')} {low.get('Product','')} at {fmt_pct(low.get('Margin %'))}.")
        if price_gap == price_gap and cost_gap == cost_gap:
            if abs(cost_gap) <= max(0.01, abs(price_gap) * 0.25):
                bullets.append("The margin difference appears driven mainly by selling price/revenue, because unit costs are relatively close compared with the price gap.")
            elif abs(price_gap) <= max(0.01, abs(cost_gap) * 0.25):
                bullets.append("The margin difference appears driven mainly by cost structure, because selling prices are relatively close compared with the cost gap.")
            else:
                bullets.append("Both selling price and cost structure appear to contribute to the margin difference.")
    if not loc_summary.empty and len(loc_summary) >= 2:
        cheapest = loc_summary.iloc[0]
        expensive = loc_summary.iloc[-1]
        bullets.append(f"Cheapest detected average production location: {cheapest['Location']} at {fmt_currency(cheapest['Total unit cost mean'], currency)} average unit cost; highest detected average location: {expensive['Location']} at {fmt_currency(expensive['Total unit cost mean'], currency)}.")
        component_clues = []
        for col, label in [("Material mean", "material"), ("Labor mean", "labor"), ("Handling mean", "handling/logistics"), ("Overhead mean", "overhead")]:
            if col in loc_summary.columns and cheapest.get(col) == cheapest.get(col) and expensive.get(col) == expensive.get(col):
                diff = expensive.get(col) - cheapest.get(col)
                if diff > 0:
                    component_clues.append(f"{label} is lower by about {fmt_currency(diff, currency)}")
        if component_clues:
            bullets.append(f"The lower-cost location is explained by these detected component differences: {', '.join(component_clues[:4])}.")
        else:
            bullets.append("The workbook has location cost differences, but not enough component-level detail to fully explain why one factory is cheaper. Add material/labor/handling/overhead columns by location for a stronger answer.")
    if offline_mode:
        bullets.append("Offline/security mode: no external market or supplier APIs are used. Market comparison is limited to uploaded benchmark sheets or files the user explicitly provides.")

    ai_text = ""
    if llm:
        prompt = f"""
Question: {question}
Offline mode: {offline_mode}
Workbook: {workbook.filename}
Relevant product rows: {margin_summary.head(30).to_dict(orient='records')}
Location summary: {loc_summary.head(30).to_dict(orient='records') if not loc_summary.empty else []}
Market benchmark data detected: {bool(market_tables)}

Answer the question using only the supplied workbook data. Explain margin differences, production location cost differences, and market-comparison limits. Do not invent external market prices.
"""
        result = llm.generate(prompt, system="You are a business analyst. Use only the provided data. Be concise and explicit about data gaps.")
        ai_text = result.text if result.ok else f"Local AI answer unavailable: {result.error}"

    sections = [
        card("User question", f"<p>{esc(question)}</p><div class='note'>{''.join(f'<p>• {esc(b)}</p>' for b in bullets)}</div>"),
        card("Relevant product and margin data", dataframe_table(margin_summary, currency, numeric_currency_cols=["Unit price", "Total unit cost", "Material", "Labor", "Handling", "Overhead", "Margin/unit"], pct_cols=["Margin %"])),
    ]
    if not loc_summary.empty:
        sections.append(card("Production/factory location cost comparison", dataframe_table(loc_summary, currency, numeric_currency_cols=[c for c in loc_summary.columns if c != "Location"], pct_cols=["Margin % mean"])))
    sections.append(card("Market comparison data availability", f"<p>{esc(market_msg)}</p>{market_html}"))
    if ai_text:
        sections.append(card("Local AI answer", f"<div class='ai-box'>{esc(ai_text)}</div>"))
    return render_page("Ad-hoc Business Question", f"Workbook: {workbook.filename}", sections, output_path)


def goal_analysis(
    workbook: WorkbookData,
    goal: str,
    currency: str = "€",
    llm: Optional[OllamaClient] = None,
    output_path: Optional[str] = None,
    offline_mode: bool = True,
    max_internal_rows: int = 3000,
    max_market_rows: int = 60000,
) -> str:
    """Iterative-style goal mining report from workbook data.

    This is a deterministic first version of a `/goal` mode: it searches for
    connections relevant to a user goal across internal product/cost data,
    production locations, margins, and uploaded competitor/market benchmark rows.
    """
    from difflib import SequenceMatcher
    from .product_matching import product_family, product_signature, match_score
    from .insight_engine import make_insight, save_review_queue, update_goal_state, insights_to_table_rows

    goal = (goal or "Find relevant margin, cost, production and market insights.").strip()
    products = extract_products(workbook)
    df = products_to_dataframe(products)
    if df.empty:
        return render_page(
            "Goal Insight Mining",
            f"Workbook: {workbook.filename}",
            [card("Goal", f"<p>{esc(goal)}</p><p class='warn'>No product-like data was detected. Generate a schema report or provide a mapping profile first.</p>")],
            output_path,
        )

    clipped_internal = False
    if len(df) > max_internal_rows:
        df = df.head(max_internal_rows).copy()
        clipped_internal = True

    def tokens(text: Any) -> set[str]:
        return {t for t in normalize_text(text).split() if len(t) >= 3 and t not in {"the", "and", "for", "with", "from", "product", "item"}}

    goal_tokens = tokens(goal)
    df["Product family"] = df.apply(lambda r: product_family(r.get("Product", ""), r.get("Category", ""), r.get("SKU", "")), axis=1)

    def relevance_text(*values: Any) -> int:
        combined = tokens(" ".join(str(v) for v in values))
        return len(goal_tokens & combined)

    # 1) Margin outliers.
    valid_margin = df[df["Unit price"].notna() & df["Total unit cost"].notna()].copy()
    valid_margin["Goal relevance"] = valid_margin.apply(lambda r: relevance_text(r.get("SKU"), r.get("Product"), r.get("Category"), r.get("Location")), axis=1) if not valid_margin.empty else []
    high_margin = valid_margin.sort_values(["Goal relevance", "Margin %"], ascending=[False, False]).head(15) if not valid_margin.empty else pd.DataFrame()
    low_margin = valid_margin.sort_values(["Goal relevance", "Margin %"], ascending=[False, True]).head(15) if not valid_margin.empty else pd.DataFrame()

    # 2) Similar cost but different margin/price connections.
    pairs = []
    pair_base = valid_margin.copy()
    if not pair_base.empty:
        pair_base["Group"] = pair_base.get("Product family", pair_base["Category"]).where(pair_base.get("Product family", pair_base["Category"]).astype(str).str.strip() != "", pair_base["Category"].where(pair_base["Category"].astype(str).str.strip() != "", "All"))
        # Limit pair search for speed.
        pair_base = pair_base.sort_values("Goal relevance", ascending=False).head(min(len(pair_base), 800))
        for group, g in pair_base.groupby("Group", dropna=False):
            g = g.sort_values("Total unit cost").reset_index(drop=True)
            records = g.to_dict(orient="records")
            for i, a in enumerate(records):
                ca = a.get("Total unit cost")
                pa = a.get("Unit price")
                ma = a.get("Margin %")
                if ca != ca or ca <= 0:
                    continue
                for b in records[i + 1 : min(i + 36, len(records))]:
                    cb = b.get("Total unit cost")
                    pb = b.get("Unit price")
                    mb = b.get("Margin %")
                    if cb != cb or cb <= 0:
                        continue
                    rel_cost_diff = abs(ca - cb) / max(ca, cb, 0.01)
                    if rel_cost_diff > 0.08:
                        break
                    margin_diff = abs((ma if ma == ma else 0) - (mb if mb == mb else 0))
                    price_diff = abs((pa if pa == pa else 0) - (pb if pb == pb else 0))
                    if margin_diff >= 0.08 or price_diff / max(pa or 0, pb or 0, 0.01) >= 0.10:
                        # Put higher-margin product first.
                        high, low = (a, b) if (ma if ma == ma else -999) >= (mb if mb == mb else -999) else (b, a)
                        pairs.append({
                            "Higher margin product": high.get("Product") or high.get("SKU"),
                            "Higher margin SKU": high.get("SKU"),
                            "Lower margin product": low.get("Product") or low.get("SKU"),
                            "Lower margin SKU": low.get("SKU"),
                            "Category/group": group,
                            "Cost A": high.get("Total unit cost"),
                            "Cost B": low.get("Total unit cost"),
                            "Relative cost difference": rel_cost_diff,
                            "Price A": high.get("Unit price"),
                            "Price B": low.get("Unit price"),
                            "Margin A": high.get("Margin %"),
                            "Margin B": low.get("Margin %"),
                            "Margin gap": margin_diff,
                            "Likely connection": "similar cost but different selling price/market positioning" if price_diff > abs(ca - cb) else "similar cost but different cost mix or margin policy",
                            "Goal relevance": int(high.get("Goal relevance", 0)) + int(low.get("Goal relevance", 0)),
                        })
        pairs = sorted(pairs, key=lambda x: (x.get("Goal relevance", 0), x.get("Margin gap", 0)), reverse=True)[:40]
    pair_df = pd.DataFrame(pairs)

    # 3) Location/factory cost connections for same SKU/product.
    loc_rows = []
    loc_base = df[df["Location"].astype(str).str.strip() != ""].copy()
    loc_base = loc_base[loc_base["Total unit cost"].notna()]
    if not loc_base.empty:
        loc_base["Key"] = loc_base["SKU"].where(loc_base["SKU"].astype(str).str.strip() != "", loc_base["Product"])
        for key, g in loc_base.groupby("Key", dropna=False):
            if g["Location"].nunique() < 2:
                continue
            cheapest = g.sort_values("Total unit cost").iloc[0]
            expensive = g.sort_values("Total unit cost").iloc[-1]
            cost_gap = expensive["Total unit cost"] - cheapest["Total unit cost"]
            drivers = []
            for col, label in [("Material", "material"), ("Labor", "labor"), ("Handling", "handling/logistics"), ("Overhead", "overhead")]:
                cv, ev = cheapest.get(col), expensive.get(col)
                if cv == cv and ev == ev:
                    diff = ev - cv
                    if abs(diff) > 0.01:
                        drivers.append(f"{label}: {fmt_currency(diff, currency)}")
            loc_rows.append({
                "Product/SKU": key,
                "Product": cheapest.get("Product") or expensive.get("Product"),
                "Cheapest location": cheapest["Location"],
                "Cheapest unit cost": cheapest["Total unit cost"],
                "Most expensive location": expensive["Location"],
                "Most expensive unit cost": expensive["Total unit cost"],
                "Cost gap": cost_gap,
                "Cost gap %": cost_gap / max(expensive["Total unit cost"], 0.01),
                "Detected component drivers": "; ".join(drivers) if drivers else "cost gap detected; add material/labor/handling/overhead by location for stronger driver detail",
                "Goal relevance": relevance_text(key, cheapest.get("Product"), cheapest.get("Location"), expensive.get("Location")),
            })
    loc_compare = pd.DataFrame(loc_rows).sort_values(["Goal relevance", "Cost gap"], ascending=[False, False]).head(40) if loc_rows else pd.DataFrame()

    # 4) Market benchmark rows from uploaded competitor/market sheets.
    market_rows = []
    market_clipped = False
    for table in workbook.tables:
        name = normalize_text(table.name)
        roles = table.schema.roles if table.schema else {}
        if not ("competitor" in roles or "market" in name or "competitor" in name or "benchmark" in name):
            continue
        product_col = table.schema.role_column("product") if table.schema else None
        price_col = table.schema.role_column("unit_price") if table.schema else None
        competitor_col = table.schema.role_column("competitor") if table.schema else None
        location_col = table.schema.role_column("location") if table.schema else None
        category_col = table.schema.role_column("category") if table.schema else None
        if not product_col or not price_col:
            continue
        for _, row in table.dataframe.iterrows():
            if len(market_rows) >= max_market_rows:
                market_clipped = True
                break
            product_name = str(_get_cell(row, product_col, "")).strip()
            price = _get_num(row, price_col)
            if not product_name or price != price:
                continue
            market_category = str(_get_cell(row, category_col, "")).strip()
            sig = product_signature(product_name, market_category, "")
            market_rows.append({
                "Market product": product_name,
                "Market price": price,
                "Competitor": str(_get_cell(row, competitor_col, "")).strip(),
                "Market region/location": str(_get_cell(row, location_col, "")).strip(),
                "Market category": market_category,
                "Source sheet": table.name,
                "Product family": sig.get("family"),
                "Tokens": set(sig.get("tokens", set())) | ({"family:" + str(sig.get("family"))} if sig.get("family") else set()),
                "Signature": sig,
            })
        if market_clipped:
            break
    market_df = pd.DataFrame(market_rows)

    # Build inverted token index for scalable matching.
    market_matches = []
    if not market_df.empty and not valid_margin.empty:
        token_index: Dict[str, List[int]] = {}
        for idx, row in market_df.iterrows():
            for tok in row.get("Tokens", set()):
                token_index.setdefault(tok, []).append(int(idx))
        internal_for_match = valid_margin.sort_values("Goal relevance", ascending=False).head(min(len(valid_margin), 500))
        for _, prod in internal_for_match.iterrows():
            prod_label = str(prod.get("Product") or prod.get("SKU") or "")
            prod_sig = product_signature(prod_label, prod.get("Category", ""), prod.get("SKU", ""))
            prod_tokens = set(prod_sig.get("tokens", set())) | ({"family:" + str(prod_sig.get("family"))} if prod_sig.get("family") else set())
            candidate_ids: set[int] = set()
            for tok in prod_tokens:
                candidate_ids.update(token_index.get(tok, [])[:1000])
            if not candidate_ids and prod_label:
                # fallback for short names: sample first rows only
                candidate_ids = set(range(min(2000, len(market_df))))
            scored = []
            for cid in list(candidate_ids)[:5000]:
                mrow = market_df.iloc[cid]
                mtoks = mrow.get("Tokens", set())
                overlap = len(prod_tokens & mtoks) / max(1, len(prod_tokens | mtoks))
                seq = SequenceMatcher(None, normalize_text(prod_label), normalize_text(mrow.get("Market product", ""))).ratio()
                rich = match_score(prod_sig, mrow.get("Signature", {}))
                score = overlap * 0.40 + seq * 0.25 + rich * 0.35
                if score >= 0.28:
                    scored.append((score, mrow))
            if not scored:
                continue
            scored.sort(key=lambda x: x[0], reverse=True)
            top_scored = scored[:25]
            prices = [float(x[1]["Market price"]) for x in top_scored if x[1]["Market price"] == x[1]["Market price"]]
            if not prices:
                continue
            avg_market = sum(prices) / len(prices)
            our_price = prod.get("Unit price")
            market_matches.append({
                "Internal product": prod_label,
                "SKU": prod.get("SKU"),
                "Our price": our_price,
                "Avg matched market price": avg_market,
                "Market min": min(prices),
                "Market max": max(prices),
                "Our vs market avg": (our_price - avg_market) if our_price == our_price else math.nan,
                "Our vs market avg %": ((our_price - avg_market) / avg_market) if our_price == our_price and avg_market else math.nan,
                "Best match": top_scored[0][1].get("Market product"),
                "Best match competitor": top_scored[0][1].get("Competitor"),
                "Match confidence": top_scored[0][0],
                "Matched rows": len(prices),
                "Goal relevance": prod.get("Goal relevance", 0),
            })
    market_match_df = pd.DataFrame(market_matches).sort_values(["Goal relevance", "Match confidence"], ascending=[False, False]).head(60) if market_matches else pd.DataFrame()

    # 5) Executive deterministic insight list.
    insight_bullets = []
    if clipped_internal:
        insight_bullets.append(f"Internal product analysis was clipped to the first {max_internal_rows:,} detected rows for responsiveness. For production-scale analysis, use mapping profiles and future indexed/SQLite mode.")
    if market_clipped:
        insight_bullets.append(f"Market benchmark analysis was clipped to {max_market_rows:,} uploaded benchmark rows for responsiveness.")
    if not pair_df.empty:
        first = pair_df.iloc[0]
        insight_bullets.append(f"Potential pricing/margin connection: {first['Higher margin product']} has a materially different margin than {first['Lower margin product']} despite similar unit cost; likely driver: {first['Likely connection']}.")
    if not loc_compare.empty:
        first = loc_compare.iloc[0]
        insight_bullets.append(f"Factory/location connection: {first['Cheapest location']} is cheaper than {first['Most expensive location']} for {first['Product/SKU']} by {fmt_currency(first['Cost gap'], currency)} per unit ({fmt_pct(first['Cost gap %'])}).")
    if not market_match_df.empty:
        first = market_match_df.iloc[0]
        gap = first.get("Our vs market avg %")
        direction = "above" if gap == gap and gap > 0 else "below"
        insight_bullets.append(f"Uploaded market benchmark connection: {first['Internal product']} appears {direction} matched market average by {fmt_pct(abs(gap)) if gap == gap else 'an unknown %'} based on {int(first['Matched rows'])} matched benchmark rows.")
    if offline_mode:
        insight_bullets.append("Offline/data-security mode: insights are limited to uploaded files and local calculations; no external market lookup was performed.")
    if not insight_bullets:
        insight_bullets.append("The workbook was read, but no strong connection patterns were found with the current heuristics. Add clearer product, price, cost, location and market benchmark columns, or provide a narrower goal.")

    # 6) Create scored insight objects and persist a manual review queue + goal state.
    scored_insights: List[Dict[str, Any]] = []
    if not pair_df.empty:
        for _, row in pair_df.head(12).iterrows():
            margin_gap = row.get("Margin gap", 0) if row.get("Margin gap", 0) == row.get("Margin gap", 0) else 0
            rel_cost = row.get("Relative cost difference", 1) if row.get("Relative cost difference", 1) == row.get("Relative cost difference", 1) else 1
            scored_insights.append(make_insight(
                kind="similar_cost_margin_gap",
                title=f"Similar cost but different margin: {row.get('Higher margin product')} vs {row.get('Lower margin product')}",
                summary=f"{row.get('Higher margin product')} and {row.get('Lower margin product')} have similar unit costs but a margin gap of {fmt_pct(margin_gap)}. Likely driver: {row.get('Likely connection')}.",
                recommendation="Validate product positioning and market benchmark fit; consider price or margin-policy review for the lower-margin item.",
                evidence=row.to_dict(),
                impact=min(1.0, abs(float(margin_gap)) * 2.5),
                confidence=max(0.35, min(0.95, 1.0 - float(rel_cost) * 4.0)),
                actionability=0.82,
                relevance=min(1.0, 0.45 + float(row.get("Goal relevance", 0)) * 0.12),
                urgency=0.58,
            ))
    if not loc_compare.empty:
        for _, row in loc_compare.head(12).iterrows():
            gap_pct = row.get("Cost gap %", 0) if row.get("Cost gap %", 0) == row.get("Cost gap %", 0) else 0
            scored_insights.append(make_insight(
                kind="factory_cost_gap",
                title=f"Factory cost gap: {row.get('Cheapest location')} vs {row.get('Most expensive location')} for {row.get('Product/SKU')}",
                summary=f"{row.get('Cheapest location')} is cheaper than {row.get('Most expensive location')} by {fmt_currency(row.get('Cost gap'), currency)} per unit ({fmt_pct(gap_pct)}).",
                recommendation="Review whether more volume can move to the cheaper location, while checking capacity, lead time, risk, quality and logistics constraints.",
                evidence=row.to_dict(),
                impact=min(1.0, abs(float(gap_pct)) * 2.0),
                confidence=0.72 if "add material" in str(row.get("Detected component drivers", "")) else 0.88,
                actionability=0.76,
                relevance=min(1.0, 0.45 + float(row.get("Goal relevance", 0)) * 0.12),
                urgency=0.50,
            ))
    if not market_match_df.empty:
        for _, row in market_match_df.head(15).iterrows():
            gap_pct = row.get("Our vs market avg %", 0) if row.get("Our vs market avg %", 0) == row.get("Our vs market avg %", 0) else 0
            direction = "above" if gap_pct > 0 else "below"
            scored_insights.append(make_insight(
                kind="market_price_gap",
                title=f"Market price gap: {row.get('Internal product')} appears {direction} uploaded benchmark average",
                summary=f"Our price is {direction} the matched uploaded market average by {fmt_pct(abs(gap_pct))}, based on {int(row.get('Matched rows', 0))} matched rows and confidence {fmt_pct(row.get('Match confidence'))}.",
                recommendation="Manually validate the match in the review queue. If accepted, use it for price-positioning, margin or sales-strategy review.",
                evidence=row.to_dict(),
                impact=min(1.0, abs(float(gap_pct)) * 2.0),
                confidence=max(0.25, min(0.95, float(row.get("Match confidence", 0.4)))),
                actionability=0.70,
                relevance=min(1.0, 0.45 + float(row.get("Goal relevance", 0)) * 0.12),
                urgency=0.55,
            ))
    if not valid_margin.empty:
        worst = valid_margin.sort_values("Margin %", ascending=True).head(8)
        for _, row in worst.iterrows():
            m = row.get("Margin %", 0) if row.get("Margin %", 0) == row.get("Margin %", 0) else 0
            if m < 0.18:
                scored_insights.append(make_insight(
                    kind="low_margin_risk",
                    title=f"Low margin risk: {row.get('Product') or row.get('SKU')}",
                    summary=f"Detected margin is {fmt_pct(m)}, which may need pricing, cost or product-mix review.",
                    recommendation="Check market position, BOM/cost components, handling costs and whether production location changes can improve margin.",
                    evidence=row.to_dict(),
                    impact=min(1.0, max(0.0, 0.30 - float(m)) * 2.5),
                    confidence=0.78,
                    actionability=0.70,
                    relevance=min(1.0, 0.35 + float(row.get("Goal relevance", 0)) * 0.12),
                    urgency=0.65,
                ))

    review_queue_file = ""
    goal_state_file = ""
    if output_path:
        session_dir = Path(output_path).expanduser().resolve().parent
        review_queue_file = save_review_queue(session_dir, scored_insights, merge=True)
        next_search = [
            "Review and accept/reject the highest-scoring market matches in insights_review_queue.json.",
            "For accepted factory-cost insights, check capacity, quality, lead time and logistics constraints.",
            "For accepted similar-cost margin gaps, validate whether the price gap is market-positioning or data-quality driven.",
        ]
        goal_state_file = update_goal_state(session_dir, goal, scored_insights, next_search_areas=next_search)

    ai_text = ""
    if llm:
        prompt = f"""
Goal: {goal}
Offline mode: {offline_mode}
Workbook: {workbook.filename}
Deterministic insight bullets: {insight_bullets}
High margin sample: {high_margin.head(15).to_dict(orient='records') if not high_margin.empty else []}
Low margin sample: {low_margin.head(15).to_dict(orient='records') if not low_margin.empty else []}
Similar-cost/different-margin pairs: {pair_df.head(20).to_dict(orient='records') if not pair_df.empty else []}
Location comparisons: {loc_compare.head(20).to_dict(orient='records') if not loc_compare.empty else []}
Market matches: {market_match_df.head(20).to_dict(orient='records') if not market_match_df.empty else []}

Write an executive insight summary. Use only uploaded workbook data. Do not invent market data. State data gaps clearly.
"""
        result = llm.generate(prompt, system="You are a business strategy analyst. Return concise, actionable insights with caveats.")
        ai_text = result.text if result.ok else f"Local AI goal commentary unavailable: {result.error}"

    sections = [
        card("Goal", f"<p>{esc(goal)}</p><div class='note'>{''.join(f'<p>• {esc(b)}</p>' for b in insight_bullets)}</div>"),
        card("Dataset scale and readiness", "<div class='grid'>" + "".join([
            kpi("Detected internal rows", fmt_number(len(df), 0), "Product/cost/location-like rows"),
            kpi("Uploaded market rows", fmt_number(len(market_df), 0), "Competitor/benchmark rows detected"),
            kpi("Similar-cost margin pairs", fmt_number(len(pair_df), 0), "Potential pricing/margin connections"),
            kpi("Location comparisons", fmt_number(len(loc_compare), 0), "Same product across locations"),
        ]) + "</div>"),
    ]
    if scored_insights:
        insight_rows = pd.DataFrame(insights_to_table_rows(scored_insights))
        queue_note = ""
        if review_queue_file or goal_state_file:
            queue_note = f"<div class='note'><strong>Manual review queue:</strong> <code>{esc(review_queue_file)}</code><br><strong>Persistent goal state:</strong> <code>{esc(goal_state_file)}</code><br>Use the CLI <code>insights</code> commands to accept/reject insights and continue the same goal later with the same session folder.</div>"
        sections.append(card("Scored insights and manual review queue", queue_note + dataframe_table(insight_rows, currency, numeric_currency_cols=["Score", "Impact", "Confidence", "Actionability"])))
    if ai_text:
        sections.append(card("Local AI goal summary", f"<div class='ai-box'>{esc(ai_text)}</div>"))
    if not pair_df.empty:
        sections.append(card("Similar production cost but different margin/price", dataframe_table(pair_df, currency, numeric_currency_cols=["Cost A", "Cost B", "Price A", "Price B"], pct_cols=["Relative cost difference", "Margin A", "Margin B", "Margin gap"])))
    if not loc_compare.empty:
        sections.append(card("Factory/location cost connections", dataframe_table(loc_compare, currency, numeric_currency_cols=["Cheapest unit cost", "Most expensive unit cost", "Cost gap"], pct_cols=["Cost gap %"])))
    if not market_match_df.empty:
        sections.append(card("Uploaded market benchmark matches", dataframe_table(market_match_df, currency, numeric_currency_cols=["Our price", "Avg matched market price", "Market min", "Market max", "Our vs market avg"], pct_cols=["Our vs market avg %", "Match confidence"])))
    if not high_margin.empty or not low_margin.empty:
        sections.append(card("Margin outliers relevant to goal", "<h3>High margin</h3>" + dataframe_table(high_margin.head(20), currency, numeric_currency_cols=["Unit price", "Total unit cost", "Material", "Labor", "Handling", "Overhead", "Margin/unit"], pct_cols=["Margin %"]) + "<h3>Low margin</h3>" + dataframe_table(low_margin.head(20), currency, numeric_currency_cols=["Unit price", "Total unit cost", "Material", "Labor", "Handling", "Overhead", "Margin/unit"], pct_cols=["Margin %"])))
    if not market_df.empty:
        market_preview = market_df.drop(columns=["Tokens"], errors="ignore").head(80)
        sections.append(card("Uploaded market/competitor benchmark preview", dataframe_table(market_preview, currency, max_rows=80, numeric_currency_cols=["Market price"])))
    return render_page("Goal Insight Mining", f"Workbook: {workbook.filename}", sections, output_path)
