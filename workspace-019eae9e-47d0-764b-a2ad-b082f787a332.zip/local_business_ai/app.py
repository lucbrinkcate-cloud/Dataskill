from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from flask import request, send_from_directory, url_for, redirect
from flask import Flask
from werkzeug.utils import secure_filename

from core.audit import create_audit_record, load_approval_register, set_output_status
from core.business_logic import (
    extract_products,
    full_report,
    goal_analysis,
    margin_analysis,
    product_comparison,
    production_optimization,
    question_analysis,
    scenario_analysis,
    schema_report,
)
from core.config_manager import load_config, save_config, update_from_form
from core.excel_reader import read_workbook
from core.exporters import export_html
from core.html_renderer import DEFAULT_STYLE, card, dataframe_table, esc
from core.insight_engine import load_review_queue, set_insight_status, load_goal_state
from core.llm import OllamaClient
from core.planner import build_plan
from core.schema_mapper import safe_number
from core.session_outputs import session_output_dir
from core.template_manager import list_templates, render_document_template, selected_lines_from_products

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
GENERATED_DIR = BASE_DIR / "generated"
UPLOAD_DIR.mkdir(exist_ok=True)
GENERATED_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"xlsx", "xlsm", "xltx", "xltm", "xls", "csv"}
ALL_OUTPUTS = [
    ("full_report", "Full business report"),
    ("margin_analysis", "Margin analysis"),
    ("production_optimization", "Production location / volume optimization"),
    ("product_comparison", "Product, component and market comparison"),
    ("scenario_analysis", "Scenario / sensitivity analysis"),
    ("question_analysis", "Ad-hoc business question analysis"),
    ("goal_analysis", "Goal insight mining / connection finder"),
    ("schema_report", "Workbook schema/readiness report"),
    ("invoice", "Invoice draft"),
    ("quotation", "Quotation draft"),
]
ALL_FORMATS = [("html", "HTML"), ("pdf", "PDF"), ("docx", "Word/DOCX")]

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 250 * 1024 * 1024


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def app_page(title: str, body: str, subtitle: str = "Plan first, confirm, then generate business outputs locally.") -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)}</title>
<style>{DEFAULT_STYLE}
.form-grid {{ display:grid; grid-template-columns: repeat(12, 1fr); gap: 14px; }}
.field {{ grid-column: span 6; }}
.field.third {{ grid-column: span 4; }}
.field.full {{ grid-column: span 12; }}
label {{ display:block; font-size:13px; color:#344054; font-weight:800; margin-bottom:6px; }}
input, select, textarea {{ width:100%; border:1px solid var(--line); border-radius:12px; padding:11px 12px; font:inherit; background:#fff; }}
input[type="checkbox"] {{ width:auto; margin-right:7px; }}
textarea {{ min-height:90px; }}
button, .button {{ display:inline-flex; align-items:center; gap:8px; border:0; border-radius:12px; padding:11px 16px; font-weight:900; color:#fff; background:var(--primary); text-decoration:none; cursor:pointer; }}
.button.secondary, button.secondary {{ background:#0e7c86; }}
.button.ghost {{ background:#fff; color:var(--primary); border:1px solid var(--line); }}
.help {{ color:var(--muted); font-size:12px; margin-top:5px; }}
.option-grid {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px; }}
.option {{ border:1px solid var(--line); border-radius:14px; padding:12px; background:#fbfdff; }}
.nav {{ display:flex; gap:10px; flex-wrap:wrap; margin: 0 0 18px; }}
code {{ background:#eef2f7; padding:2px 5px; border-radius:6px; }}
@media(max-width:760px){{ .field, .field.third {{ grid-column: span 12; }} }}
</style>
</head>
<body>
<header class="hero">
  <h1>{esc(title)}</h1>
  <p>{esc(subtitle)}</p>
</header>
<main>
<div class="nav"><a class="button ghost" href="/dashboard">Dashboard</a><a class="button ghost" href="/settings">Settings</a><a class="button ghost" href="/approvals">Approvals</a><a class="button ghost" href="/insights">Insights</a><a class="button ghost" href="/templates">Templates</a></div>
{body}
</main>
</body>
</html>"""


def cfg_get(cfg: Dict[str, Any], *path: str, default: Any = "") -> Any:
    cur: Any = cfg
    for p in path:
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur


def checkbox(name: str, value: str, label: str, checked_values: Sequence[str]) -> str:
    checked = " checked" if value in checked_values else ""
    return f"<label class='option'><input type='checkbox' name='{esc(name)}' value='{esc(value)}'{checked}>{esc(label)}</label>"


def is_local_url(url: str) -> bool:
    u = (url or "").lower().strip()
    return u.startswith("http://localhost") or u.startswith("http://127.0.0.1") or u.startswith("http://[::1]")


def llm_from_options(options: Dict[str, Any]) -> Optional[OllamaClient]:
    if not options.get("use_ai"):
        return None
    if options.get("offline_mode", True) and not is_local_url(options.get("ollama_url", "")):
        return None
    return OllamaClient(model=options.get("model", "qwen2.5:7b"), base_url=options.get("ollama_url", "http://localhost:11434"))


def save_uploaded_files(files: Sequence[Any]) -> List[str]:
    stored: List[str] = []
    for file in files:
        if not file or not getattr(file, "filename", ""):
            continue
        if not allowed_file(file.filename):
            continue
        safe = secure_filename(file.filename)
        stored_name = f"{uuid.uuid4().hex[:10]}_{safe}"
        file.save(UPLOAD_DIR / stored_name)
        stored.append(stored_name)
    return stored


def stored_paths(file_ids: Sequence[str]) -> List[str]:
    paths = []
    for fid in file_ids:
        safe = secure_filename(fid)
        p = UPLOAD_DIR / safe
        if p.exists():
            paths.append(str(p.resolve()))
    return paths


def parse_dashboard_options(form: Any, cfg: Dict[str, Any]) -> Dict[str, Any]:
    outputs = form.getlist("outputs") if hasattr(form, "getlist") else []
    formats = form.getlist("formats") if hasattr(form, "getlist") else []
    if not outputs:
        outputs = cfg_get(cfg, "defaults", "outputs", default=["full_report"])
    if not formats:
        formats = cfg_get(cfg, "defaults", "formats", default=["html"])
    select = form.get("document_select", cfg_get(cfg, "defaults", "document_select", default="positive-margin"))
    custom_skus = str(form.get("custom_skus", "") or "").strip()
    if select == "custom_skus" and custom_skus:
        select = "sku:" + custom_skus
    return {
        "outputs": outputs,
        "formats": formats,
        "currency": form.get("currency", cfg_get(cfg, "defaults", "currency", default="€")) or "€",
        "tax_rate": safe_number(form.get("tax_rate", cfg_get(cfg, "defaults", "tax_rate", default=21)), 21),
        "out_dir": form.get("out_dir", cfg_get(cfg, "defaults", "output_dir", default="generated/dashboard_runs")) or "generated/dashboard_runs",
        "company": form.get("company", cfg_get(cfg, "company", "name", default="Your Company")) or "Your Company",
        "customer": form.get("customer", "Customer") or "Customer",
        "notes": form.get("notes", "") or "",
        "document_select": select,
        "quantities": form.get("quantities", "") or "",
        "default_qty": safe_number(form.get("default_qty", cfg_get(cfg, "defaults", "default_qty", default=1)), 1),
        "max_lines": int(safe_number(form.get("max_lines", cfg_get(cfg, "defaults", "max_lines", default=200)), 200)),
        "invoice_template": form.get("invoice_template", cfg_get(cfg, "templates", "invoice", default="invoice_basic")) or "invoice_basic",
        "quotation_template": form.get("quotation_template", cfg_get(cfg, "templates", "quotation", default="quotation_basic")) or "quotation_basic",
        "template_dir": form.get("template_dir", cfg_get(cfg, "templates", "template_dir", default="")) or "",
        "use_ai": form.get("use_ai", "yes" if cfg_get(cfg, "ai", "use_ai", default=True) else "no") == "yes",
        "model": form.get("model", cfg_get(cfg, "ai", "model", default="qwen2.5:7b")) or "qwen2.5:7b",
        "ollama_url": form.get("ollama_url", cfg_get(cfg, "ai", "ollama_url", default="http://localhost:11434")) or "http://localhost:11434",
        "audit": form.get("audit", "yes" if cfg_get(cfg, "workflow", "write_audit_trail", default=True) else "no") == "yes",
        "offline_mode": form.get("offline_mode", "yes" if cfg_get(cfg, "workflow", "offline_mode", default=True) else "no") == "yes",
        "business_question": form.get("business_question", "") or "",
        "goal": form.get("goal", "") or form.get("business_question", "") or "",
    }


def clean_uploaded_stem(path: str) -> str:
    stem = Path(path).stem
    import re
    m = re.match(r"^[0-9a-f]{10}_(.+)$", stem)
    return m.group(1) if m else stem


def parse_quantities(raw: str) -> Dict[str, float]:
    raw = (raw or "").strip()
    if not raw:
        return {}
    try:
        if raw.startswith("{"):
            return json.loads(raw)
    except Exception:
        pass
    out: Dict[str, float] = {}
    for part in raw.split(","):
        if ":" in part:
            k, v = part.split(":", 1)
            out[k.strip()] = safe_number(v.strip(), 1.0)
    return out


@app.get("/")
def index() -> str:
    return dashboard()


@app.get("/dashboard")
def dashboard() -> str:
    cfg = load_config()
    if not cfg.get("first_run_complete"):
        return settings(first_run=True)
    return dashboard_form(cfg)


@app.get("/settings")
def settings(first_run: bool = False) -> str:
    cfg = load_config()
    templates = list_templates(cfg_get(cfg, "templates", "template_dir", default=""))
    template_options = "".join(f"<option value='{esc(t.name)}'>{esc(t.name)} ({esc(t.source)})</option>" for t in templates)
    selected_outputs = cfg_get(cfg, "defaults", "outputs", default=[])
    selected_formats = cfg_get(cfg, "defaults", "formats", default=[])
    body = card("First-run setup questions" if first_run else "Settings", f"""
    <form method="post" action="{url_for('save_settings')}">
      <div class="note">The dashboard is pre-built. Your AI agent should use it to configure, plan, confirm and run jobs; it should not rebuild the dashboard each time.</div>
      <h3>Company placeholders</h3>
      <div class="form-grid">
        <div class="field"><label>Company name</label><input name="company_name" value="{esc(cfg_get(cfg,'company','name',default='Your Company'))}"></div>
        <div class="field"><label>Email</label><input name="email" value="{esc(cfg_get(cfg,'company','email',default='sales@example.com'))}"></div>
        <div class="field full"><label>Address</label><input name="company_address" value="{esc(cfg_get(cfg,'company','address',default='Company address placeholder'))}"></div>
        <div class="field"><label>VAT number</label><input name="vat_number" value="{esc(cfg_get(cfg,'company','vat_number',default='VAT number placeholder'))}"></div>
        <div class="field"><label>Bank / IBAN</label><input name="bank" value="{esc(cfg_get(cfg,'company','bank',default='Bank/IBAN placeholder'))}"></div>
        <div class="field"><label>Phone</label><input name="phone" value="{esc(cfg_get(cfg,'company','phone',default='Phone placeholder'))}"></div>
        <div class="field"><label>Currency</label><input name="currency" value="{esc(cfg_get(cfg,'defaults','currency',default='€'))}"></div>
        <div class="field"><label>Tax/VAT %</label><input name="tax_rate" type="number" step="0.01" value="{esc(cfg_get(cfg,'defaults','tax_rate',default=21))}"></div>
        <div class="field full"><label>Default output directory</label><input name="output_dir" value="{esc(cfg_get(cfg,'defaults','output_dir',default='generated/dashboard_runs'))}"></div>
      </div>
      <h3>Default outputs</h3>
      <div class="option-grid">{''.join(checkbox('outputs', v, l, selected_outputs) for v,l in ALL_OUTPUTS)}</div>
      <h3>Default formats</h3>
      <div class="option-grid">{''.join(checkbox('formats', v, l, selected_formats) for v,l in ALL_FORMATS)}</div>
      <h3>Document templates</h3>
      <div class="form-grid">
        <div class="field"><label>Invoice template</label><select name="invoice_template">{template_options}</select><div class="help">Default is invoice_basic. Use the Templates page to create custom templates.</div></div>
        <div class="field"><label>Quotation template</label><select name="quotation_template">{template_options}</select></div>
        <div class="field"><label>Default document item selection</label><select name="document_select"><option value="positive-margin">Positive margin items</option><option value="top-margin">Top margin items</option><option value="all">All detected items</option></select></div>
        <div class="field"><label>Template directory</label><input name="template_dir" value="{esc(cfg_get(cfg,'templates','template_dir',default=''))}" placeholder="Optional custom template folder"></div>
      </div>
      <h3>Local AI</h3>
      <div class="form-grid">
        <div class="field"><label>Use local AI commentary</label><select name="use_ai"><option value="yes" {'selected' if cfg_get(cfg,'ai','use_ai',default=True) else ''}>Yes, Ollama/local model</option><option value="no" {'selected' if not cfg_get(cfg,'ai','use_ai',default=True) else ''}>No, calculations only</option></select></div>
        <div class="field"><label>Model</label><input name="model" value="{esc(cfg_get(cfg,'ai','model',default='qwen2.5:7b'))}"></div>
        <div class="field full"><label>Ollama URL</label><input name="ollama_url" value="{esc(cfg_get(cfg,'ai','ollama_url',default='http://localhost:11434'))}"></div>
      </div>
      <h3>Workflow and connectors</h3>
      <div class="option-grid">
        <label class="option"><input type="checkbox" name="uploaded_market_files" checked>Use uploaded competitor/market files</label>
        <label class="option"><input type="checkbox" name="agent_web_research">Allow agent web research to create market benchmark files (disabled when offline mode is on)</label>
        <label class="option"><input type="checkbox" name="supplier_api">Supplier/API connectors configured later</label>
        <label class="option"><input type="checkbox" name="erp_accounting">ERP/accounting connectors configured later</label>
      </div>
      <div class="form-grid" style="margin-top:14px">
        <div class="field"><label>Offline/data-security mode</label><select name="offline_mode"><option value="yes" selected>Yes, local files only</option><option value="no">No, allow configured connectors later</option></select><div class="help">Offline mode disables external APIs/web connectors. Localhost Ollama is still allowed.</div></div>
        <div class="field"><label>Audit trail</label><select name="audit"><option value="yes" selected>Yes</option><option value="no">No</option></select></div>
        <div class="field"><label>Approval workflow</label><select name="approval"><option value="yes" selected>Yes</option><option value="no">No</option></select></div>
        <div class="field full"><label>Connector notes</label><textarea name="connector_notes">{esc(cfg_get(cfg,'connectors','connector_notes',default=''))}</textarea></div>
      </div>
      <p><button type="submit">Save setup and open dashboard</button></p>
    </form>
    """)
    return app_page("Setup" if first_run else "Settings", body)


@app.post("/settings")
def save_settings() -> str:
    update_from_form(request.form)
    return dashboard_form(load_config(), message="Settings saved. You can now upload files and create a plan.")


def dashboard_form(cfg: Dict[str, Any], message: str = "") -> str:
    selected_outputs = cfg_get(cfg, "defaults", "outputs", default=["full_report"])
    selected_formats = cfg_get(cfg, "defaults", "formats", default=["html"])
    templates = list_templates(cfg_get(cfg, "templates", "template_dir", default=""))
    invoice_templates = "".join(f"<option value='{esc(t.name)}' {'selected' if t.name == cfg_get(cfg,'templates','invoice',default='invoice_basic') else ''}>{esc(t.name)} ({esc(t.source)})</option>" for t in templates)
    quotation_templates = "".join(f"<option value='{esc(t.name)}' {'selected' if t.name == cfg_get(cfg,'templates','quotation',default='quotation_basic') else ''}>{esc(t.name)} ({esc(t.source)})</option>" for t in templates)
    msg_html = f"<div class='note'>{esc(message)}</div>" if message else ""
    body = card("Create a plan first", f"""
    {msg_html}
    <form method="post" action="{url_for('plan_run')}" enctype="multipart/form-data">
      <div class="note"><strong>Important workflow:</strong> the tool will upload/read the files and show a proposed plan first. It will not generate final analysis outputs until you confirm the plan.</div>
      <div class="form-grid" style="margin-top:14px">
        <div class="field full"><label>Excel/CSV files</label><input name="files" type="file" accept=".xlsx,.xlsm,.xls,.csv" multiple required><div class="help">Upload one or many files. Competitor/market files can be included in the same batch.</div></div>
        <div class="field"><label>Customer name for invoices/quotes</label><input name="customer" value="Customer"></div>
        <div class="field"><label>Company</label><input name="company" value="{esc(cfg_get(cfg,'company','name',default='Your Company'))}"></div>
        <div class="field"><label>Currency</label><input name="currency" value="{esc(cfg_get(cfg,'defaults','currency',default='€'))}"></div>
        <div class="field"><label>Tax/VAT %</label><input name="tax_rate" type="number" step="0.01" value="{esc(cfg_get(cfg,'defaults','tax_rate',default=21))}"></div>
        <div class="field full"><label>Output directory</label><input name="out_dir" value="{esc(cfg_get(cfg,'defaults','output_dir',default='generated/dashboard_runs'))}"></div>
        <div class="field full"><label>Ad-hoc business question</label><textarea name="business_question" placeholder="Example: Why is product A margin higher than product B if production costs are the same? Why is Poland cheaper than China? Compare to uploaded market benchmarks only."></textarea><div class="help">Select the question-analysis output to generate a focused answer from uploaded data only.</div></div>
        <div class="field full"><label>/goal for insight mining</label><textarea name="goal" placeholder="Example: Keep finding connections between competitor prices, our margins, production locations and material/handling cost drivers. Prioritize actionable pricing and production insights."></textarea><div class="help">Select goal-analysis to mine broader connections and relevant insights across large uploaded competitor reports.</div></div>
      </div>
      <h3>Outputs to generate after confirmation</h3>
      <div class="option-grid">{''.join(checkbox('outputs', v, l, selected_outputs) for v,l in ALL_OUTPUTS)}</div>
      <h3>Export formats</h3>
      <div class="option-grid">{''.join(checkbox('formats', v, l, selected_formats) for v,l in ALL_FORMATS)}</div>
      <h3>Invoice/quotation controls</h3>
      <div class="form-grid">
        <div class="field"><label>Item selection</label><select name="document_select"><option value="positive-margin">Positive margin items</option><option value="top-margin">Top margin items</option><option value="all">All detected items</option><option value="custom_skus">Custom SKUs below</option></select></div>
        <div class="field"><label>Custom SKUs</label><input name="custom_skus" placeholder="A-100,B-200"></div>
        <div class="field"><label>Quantities</label><input name="quantities" placeholder="A-100:10,B-200:5"></div>
        <div class="field"><label>Default quantity</label><input name="default_qty" type="number" step="0.01" value="{esc(cfg_get(cfg,'defaults','default_qty',default=1))}"></div>
        <div class="field"><label>Max document lines</label><input name="max_lines" type="number" value="{esc(cfg_get(cfg,'defaults','max_lines',default=200))}"></div>
        <div class="field"><label>Invoice template</label><select name="invoice_template">{invoice_templates}</select></div>
        <div class="field"><label>Quotation template</label><select name="quotation_template">{quotation_templates}</select></div>
        <div class="field full"><label>Notes / terms</label><textarea name="notes" placeholder="Payment terms, delivery terms, quote validity, internal notes..."></textarea></div>
      </div>
      <h3>AI and audit</h3>
      <div class="form-grid">
        <div class="field"><label>Use local AI commentary</label><select name="use_ai"><option value="yes" {'selected' if cfg_get(cfg,'ai','use_ai',default=True) else ''}>Yes</option><option value="no" {'selected' if not cfg_get(cfg,'ai','use_ai',default=True) else ''}>No</option></select></div>
        <div class="field"><label>Model</label><input name="model" value="{esc(cfg_get(cfg,'ai','model',default='qwen2.5:7b'))}"></div>
        <div class="field"><label>Ollama URL</label><input name="ollama_url" value="{esc(cfg_get(cfg,'ai','ollama_url',default='http://localhost:11434'))}"></div>
        <div class="field"><label>Audit trail</label><select name="audit"><option value="yes" selected>Yes</option><option value="no">No</option></select></div>
        <div class="field"><label>Offline/data-security mode</label><select name="offline_mode"><option value="yes" selected>Yes, local files only</option><option value="no">No</option></select></div>
      </div>
      <p><button type="submit">Read files and create plan</button></p>
    </form>
    """)
    return app_page("Business Process AI Dashboard", body)


@app.post("/plan")
def plan_run() -> str:
    cfg = load_config()
    files = request.files.getlist("files")
    file_ids = save_uploaded_files(files)
    if not file_ids:
        return app_page("Upload error", card("No valid files", "<p class='warn'>Please upload at least one .xlsx, .xlsm, .xls or .csv file.</p><p><a class='button ghost' href='/dashboard'>Back</a></p>"))
    options = parse_dashboard_options(request.form, cfg)
    paths = stored_paths(file_ids)
    plan = build_plan(paths, options)
    file_cards = []
    for f in plan["files"]:
        readiness = "".join(f"<span class='badge {'green' if ready else 'amber'}'>{esc(k)}: {'ready' if ready else 'review'}</span> " for k, ready in f["readiness"].items())
        samples = dataframe_table(__import__('pandas').DataFrame(f.get("sample_products", []))) if f.get("sample_products") else "<p class='small'>No product samples detected.</p>"
        sheets_rows = "".join(f"<li><strong>{esc(s['sheet'])}</strong>: {s['rows']} rows · roles: {esc(', '.join(f'{k}: {v}' for k,v in s.get('roles',{}).items()) or 'none')}</li>" for s in f.get("sheets", []))
        warn = "" if not f.get("blocked_outputs") else f"<div class='warn'>Needs review for: {esc(', '.join(f['blocked_outputs']))}</div>"
        suggestions = "".join(f"<li>{esc(x)}</li>" for x in f.get("suggestions", []))
        file_cards.append(card(f"Detected: {f['filename']}", f"""
        <p>{readiness}</p>{warn}
        <p><strong>Tables:</strong> {f['table_count']} · <strong>Detected product rows:</strong> {f['detected_product_rows']}</p>
        <h3>Sheets and inferred roles</h3><ul>{sheets_rows}</ul>
        <h3>Product samples</h3>{samples}
        {('<h3>Suggestions</h3><ul>'+suggestions+'</ul>') if suggestions else ''}
        """))
    hidden_file_ids = esc(json.dumps(file_ids))
    hidden_options = esc(json.dumps(options))
    outputs_checkboxes = ''.join(checkbox('outputs', v, l, options.get('outputs', [])) for v,l in ALL_OUTPUTS)
    formats_checkboxes = ''.join(checkbox('formats', v, l, options.get('formats', [])) for v,l in ALL_FORMATS)
    warnings = "".join(f"<li>{esc(w)}</li>" for w in plan.get("warnings", []))
    body = card("Plan confirmation required", f"""
    <div class="note">No final output has been generated yet. Review the detection below. If it is correct, confirm. If not, go back/change options or generate a schema report first.</div>
    {('<div class="warn"><strong>Warnings:</strong><ul>'+warnings+'</ul></div>') if warnings else ''}
    <form method="post" action="{url_for('generate_from_plan')}">
      <input type="hidden" name="file_ids_json" value="{hidden_file_ids}">
      <input type="hidden" name="options_json" value="{hidden_options}">
      <h3>Final outputs to generate</h3>
      <div class="option-grid">{outputs_checkboxes}</div>
      <h3>Final formats</h3>
      <div class="option-grid">{formats_checkboxes}</div>
      <div class="form-grid" style="margin-top:14px">
        <div class="field"><label>Customer</label><input name="customer" value="{esc(options.get('customer','Customer'))}"></div>
        <div class="field"><label>Company</label><input name="company" value="{esc(options.get('company','Your Company'))}"></div>
        <div class="field full"><label>Notes/terms</label><textarea name="notes">{esc(options.get('notes',''))}</textarea></div>
      </div>
      <p><button type="submit">Confirm plan and generate outputs</button> <a class="button ghost" href="/dashboard">Change approach</a></p>
    </form>
    """)
    return app_page("Review Plan", body + "".join(file_cards))


def generate_one_output(wb: Any, source_path: str, output: str, options: Dict[str, Any], llm: Optional[OllamaClient]) -> Dict[str, Any]:
    out_dir = Path(options.get("out_dir") or GENERATED_DIR).expanduser()
    if not out_dir.is_absolute():
        out_dir = BASE_DIR / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    stem_raw = clean_uploaded_stem(source_path)
    stem = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in stem_raw).strip("_") or "workbook"
    html_path = out_dir / f"{stem}_{output}.html"
    currency = options.get("currency", "€")
    if output == "margin_analysis":
        margin_analysis(wb, currency=currency, llm=llm, output_path=str(html_path))
    elif output == "production_optimization":
        production_optimization(wb, currency=currency, llm=llm, output_path=str(html_path))
    elif output == "product_comparison":
        product_comparison(wb, currency=currency, llm=llm, output_path=str(html_path))
    elif output == "scenario_analysis":
        scenario_analysis(wb, currency=currency, llm=llm, output_path=str(html_path))
    elif output == "question_analysis":
        question_analysis(wb, question=options.get("business_question", ""), currency=currency, llm=llm, output_path=str(html_path), offline_mode=options.get("offline_mode", True))
    elif output == "goal_analysis":
        goal_analysis(wb, goal=options.get("goal", "") or options.get("business_question", ""), currency=currency, llm=llm, output_path=str(html_path), offline_mode=options.get("offline_mode", True))
    elif output == "schema_report":
        schema_report(wb, currency=currency, llm=llm, output_path=str(html_path))
    elif output in {"invoice", "quotation"}:
        products = extract_products(wb)
        lines = selected_lines_from_products(
            products,
            select=options.get("document_select", "positive-margin"),
            quantities=parse_quantities(options.get("quantities", "")),
            default_qty=safe_number(options.get("default_qty", 1), 1),
            max_lines=int(safe_number(options.get("max_lines", 200), 200)),
        )
        if not lines:
            return {"output": output, "ok": False, "error": "No products selected/detected"}
        template = options.get("invoice_template" if output == "invoice" else "quotation_template") or ("invoice_basic" if output == "invoice" else "quotation_basic")
        render_document_template(
            wb,
            output,
            lines,
            output_path=str(html_path),
            template_name=template,
            company=options.get("company", "Your Company"),
            customer=options.get("customer", "Customer"),
            currency=currency,
            tax_rate=safe_number(options.get("tax_rate", 21), 21),
            notes=options.get("notes", ""),
            user_template_dir=options.get("template_dir", ""),
            extra={"dashboard_confirmed": True},
        )
    else:
        full_report(wb, currency=currency, llm=llm, output_path=str(html_path))
    exports = export_html(str(html_path), options.get("formats", ["html"]))
    return {"output": output, "ok": exports.get("ok", True), "path": str(html_path), "exports": exports}


@app.post("/generate")
def generate_from_plan() -> str:
    try:
        file_ids = json.loads(request.form.get("file_ids_json", "[]"))
        options = json.loads(request.form.get("options_json", "{}"))
    except Exception as exc:
        return app_page("Plan error", card("Invalid plan", f"<p class='warn'>{esc(exc)}</p>"))
    outputs = request.form.getlist("outputs") or options.get("outputs", ["full_report"])
    formats = request.form.getlist("formats") or options.get("formats", ["html"])
    options["outputs"] = outputs
    options["formats"] = formats
    options["customer"] = request.form.get("customer", options.get("customer", "Customer"))
    options["company"] = request.form.get("company", options.get("company", "Your Company"))
    options["notes"] = request.form.get("notes", options.get("notes", ""))
    # Every confirmed dashboard generation gets its own dated session folder.
    base_out = Path(options.get("out_dir") or "generated/dashboard_runs").expanduser()
    if not base_out.is_absolute():
        base_out = BASE_DIR / base_out
    session_dir = session_output_dir(str(base_out), label="dashboard")
    options["out_dir"] = str(session_dir)

    paths = stored_paths(file_ids)
    llm = llm_from_options(options)
    all_results = []
    result_sections = []
    for path in paths:
        wb = read_workbook(path)
        file_results = []
        for output in outputs:
            try:
                file_results.append(generate_one_output(wb, path, output, options, llm))
            except Exception as exc:
                file_results.append({"output": output, "ok": False, "error": str(exc)})
        audit_record = ""
        if options.get("audit", True):
            try:
                audit_record = create_audit_record([path], options, file_results, base_dir=str(BASE_DIR))
            except Exception as exc:
                audit_record = f"Audit failed: {exc}"
        all_results.append({"file": path, "results": file_results, "audit_record": audit_record})
        rows = []
        for r in file_results:
            exports = r.get("exports", {}).get("outputs", {}) if isinstance(r.get("exports"), dict) else {}
            links = []
            for fmt, p in exports.items():
                try:
                    rel = Path(p).resolve().relative_to(GENERATED_DIR.resolve())
                    href = url_for("generated_file", filename=str(rel))
                except Exception:
                    href = "file://" + str(p)
                links.append(f"<a class='button ghost' target='_blank' href='{esc(href)}'>{esc(fmt.upper())}</a>")
            rows.append(f"<tr><td>{esc(r.get('output'))}</td><td>{'OK' if r.get('ok') else 'Error'}</td><td>{' '.join(links) if links else esc(r.get('error',''))}</td></tr>")
        result_sections.append(card(f"Generated for {Path(path).name}", f"""
        <div class="table-wrap"><table><thead><tr><th>Output</th><th>Status</th><th>Files</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
        {f'<p class="small">Audit record: <code>{esc(audit_record)}</code></p>' if audit_record else ''}
        """))
    body = card("Generation complete", f"<div class='note'>Outputs are generated as drafts. Review/approve them before sending externally.<br><strong>Session folder:</strong> <code>{esc(str(session_dir))}</code></div>") + "".join(result_sections)
    return app_page("Outputs Ready", body)


@app.get("/generated/<path:filename>")
def generated_file(filename: str):
    return send_from_directory(GENERATED_DIR, filename, as_attachment=False)


@app.get("/approvals")
def approvals_page() -> str:
    register = load_approval_register(str(BASE_DIR))
    rows = []
    for item in register.get("items", [])[-200:]:
        rows.append(f"<tr><td>{esc(item.get('status'))}</td><td><code>{esc(item.get('path'))}</code></td><td>{esc(item.get('updated_utc'))}</td><td>{esc(item.get('notes',''))}</td></tr>")
    body = card("Approval register", f"""
    <p class="small">Generated files start as draft. Use the CLI approval command or edit this register workflow in the next version.</p>
    <div class="table-wrap"><table><thead><tr><th>Status</th><th>Path</th><th>Updated</th><th>Notes</th></tr></thead><tbody>{''.join(rows) or '<tr><td colspan="4">No approval entries yet.</td></tr>'}</tbody></table></div>
    """)
    return app_page("Approvals", body)




@app.get("/insights")
def insights_page() -> str:
    session_dir = request.args.get("session_dir", "")
    rows = ""
    state_html = ""
    if session_dir:
        queue = load_review_queue(session_dir)
        state = load_goal_state(session_dir)
        for item in queue.get("items", []):
            scores = item.get("scores", {})
            rows += f"<tr><td><code>{esc(item.get('id'))}</code></td><td>{esc(item.get('status','new'))}</td><td>{esc(item.get('kind'))}</td><td>{esc(item.get('title'))}</td><td class='num'>{esc(scores.get('overall',''))}</td><td>{esc(item.get('summary'))}</td><td>{esc(item.get('recommendation'))}</td></tr>"
        state_html = f"<div class='note'><strong>Goal:</strong> {esc(state.get('goal',''))}<br><strong>Runs:</strong> {len(state.get('runs', []))}<br><strong>Next search areas:</strong><ul>{''.join(f'<li>{esc(x)}</li>' for x in state.get('next_search_areas', []))}</ul></div>"
    form = f"""
    <form method="get" action="/insights">
      <div class="form-grid"><div class="field full"><label>Session folder</label><input name="session_dir" value="{esc(session_dir)}" placeholder="/path/to/outputs/YYYY-MM-DD/session"></div></div>
      <p><button type="submit">Load insights</button></p>
    </form>
    """
    status_form = ""
    if session_dir:
        status_form = f"""
        <h3>Update insight status</h3>
        <form method="post" action="/insights/status">
          <input type="hidden" name="session_dir" value="{esc(session_dir)}">
          <div class="form-grid">
            <div class="field"><label>Insight ID</label><input name="id"></div>
            <div class="field"><label>Status</label><select name="status"><option>accepted</option><option>rejected</option><option>reviewing</option><option>needs_more_data</option><option>converted_to_action</option><option>new</option></select></div>
            <div class="field full"><label>Notes</label><input name="notes"></div>
          </div>
          <p><button type="submit">Update status</button></p>
        </form>
        """
    table = f"<div class='table-wrap'><table><thead><tr><th>ID</th><th>Status</th><th>Type</th><th>Title</th><th>Score</th><th>Summary</th><th>Recommendation</th></tr></thead><tbody>{rows or '<tr><td colspan=7>No insights loaded.</td></tr>'}</tbody></table></div>"
    return app_page("Insights Review Queue", card("Load session insights", form + state_html + status_form + table))


@app.post("/insights/status")
def insights_status() -> str:
    session_dir = request.form.get("session_dir", "")
    insight_id = request.form.get("id", "")
    status = request.form.get("status", "reviewing")
    notes = request.form.get("notes", "")
    try:
        set_insight_status(session_dir, insight_id, status, notes=notes)
    except Exception as exc:
        return app_page("Insight update error", card("Could not update insight", f"<div class='warn'>{esc(exc)}</div><p><a class='button ghost' href='/insights?session_dir={esc(session_dir)}'>Back</a></p>"))
    return redirect(url_for('insights_page', session_dir=session_dir))


@app.get("/templates")
def templates_page() -> str:
    cfg = load_config()
    templates = list_templates(cfg_get(cfg, "templates", "template_dir", default=""))
    rows = "".join(f"<tr><td>{esc(t.name)}</td><td>{esc(t.kind)}</td><td>{esc(t.source)}</td><td><code>{esc(t.path)}</code></td><td>{esc(t.description)}</td></tr>" for t in templates)
    body = card("Templates", f"""
    <p>Templates are editable HTML/Jinja2 files. The agent skill can create, show, update and use them from the command line.</p>
    <pre><code>python skill_cli.py templates create --name my_invoice --from-template invoice_basic
python skill_cli.py templates context --file workbook.xlsx --type invoice --out context.json
python skill_cli.py templates update --name my_invoice --file edited_invoice.html.j2</code></pre>
    <div class="table-wrap"><table><thead><tr><th>Name</th><th>Kind</th><th>Source</th><th>Path</th><th>Description</th></tr></thead><tbody>{rows}</tbody></table></div>
    """)
    return app_page("Templates", body)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    print(f"\nLocal Business AI Dashboard running at http://127.0.0.1:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=False)
